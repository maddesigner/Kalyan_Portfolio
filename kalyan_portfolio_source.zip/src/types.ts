export type CategorySlug = 'civil' | 'mechanical' | 'graphic-design' | 'ui-design' | 'video-editing';

export interface Category {
  slug: CategorySlug;
  title: string;
  description: string;
  icon: string;
  color: string;
  glowColor: string;
  image?: string;
}

export interface Project {
  id: string;
  category: CategorySlug;
  title: string;
  description: string;
  imageUrl: string;
  tags: string[];
  date: string;
  client?: string;
  tools: string[];
  details: string;
  link?: string;
  modelUrl?: string;        // GLB file URL for 3D model viewer
  sketchfabId?: string;     // Sketchfab model ID for embed
}

export interface DashboardProject extends Omit<Project, 'id'> {
  id?: string;
}
