import { BrowserRouter, Routes, Route } from 'react-router-dom';
import { AuthProvider } from './lib/auth';
import { DataProvider, useData, setGlobalCache } from './lib/DataContext';
import { useEffect } from 'react';
import Navbar from './components/Navbar';
import ProtectedRoute from './components/ProtectedRoute';
import Home from './pages/Home';
import CategoryPage from './pages/CategoryPage';
import Contact from './pages/Contact';
import Dashboard from './pages/Dashboard';
import SignIn from './pages/SignIn';

// Keeps the global sync cache in sync with the context
function CacheSync() {
  const { projects, siteContent } = useData();
  useEffect(() => {
    setGlobalCache(projects, siteContent);
  }, [projects, siteContent]);
  return null;
}

// Shows a full-screen loader while Firestore data is loading
function AppContent() {
  const { loading } = useData();

  if (loading) {
    return (
      <div className="min-h-screen bg-[#0a0e1a] flex items-center justify-center">
        <div className="text-center">
          <div className="w-12 h-12 border-2 border-[#00e676] border-t-transparent rounded-full animate-spin mx-auto mb-4" />
          <p className="font-['Orbitron'] text-xs tracking-widest text-gray-500">SYNCING FROM CLOUD...</p>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-[#0a0e1a] text-white">
      <CacheSync />
      <Navbar />
      <Routes>
        <Route path="/" element={<Home />} />
        <Route path="/category/:slug" element={<CategoryPage />} />
        <Route path="/contact" element={<Contact />} />
        <Route path="/signin" element={<SignIn />} />
        <Route
          path="/dashboard"
          element={
            <ProtectedRoute>
              <Dashboard />
            </ProtectedRoute>
          }
        />
      </Routes>
    </div>
  );
}

export default function App() {
  return (
    <BrowserRouter>
      <AuthProvider>
        <DataProvider>
          <AppContent />
        </DataProvider>
      </AuthProvider>
    </BrowserRouter>
  );
}
