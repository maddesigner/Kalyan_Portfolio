import { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { motion, AnimatePresence } from 'framer-motion';
import {
  Plus, Trash2, Edit3, Save, X, RotateCcw, Shield, ChevronDown,
  Eye, LayoutDashboard, LogOut, Contact as ContactIcon, Type, Lock,
  CheckCircle, AlertTriangle, Loader2,
} from 'lucide-react';
import { useAuth } from '../lib/auth';
import { categories } from '../lib/data';
import { useData } from '../lib/DataContext';
import { SiteContent, defaultContent } from '../lib/siteContent';
import { Project, CategorySlug, DashboardProject } from '../types';

type Tab = 'projects' | 'site-content' | 'contact-details' | 'settings';

const emptyProject: DashboardProject = {
  category: 'civil', title: '', description: '', imageUrl: '', tags: [],
  date: new Date().toISOString().split('T')[0], client: '', tools: [], details: '', link: '',
};

const contentFields: { key: keyof SiteContent; label: string; type: 'text' | 'textarea'; section: string }[] = [
  { key: 'heroSubtitle', label: 'Hero Subtitle', type: 'text', section: 'Hero' },
  { key: 'heroTitleLine1', label: 'Hero Title Line 1', type: 'text', section: 'Hero' },
  { key: 'heroTitleLine2', label: 'Hero Title Line 2 (highlighted)', type: 'text', section: 'Hero' },
  { key: 'heroTagline', label: 'Hero Tagline', type: 'textarea', section: 'Hero' },
  { key: 'scrollIndicator', label: 'Scroll Indicator Text', type: 'text', section: 'Hero' },
  { key: 'categoriesTag', label: 'Categories Tag', type: 'text', section: 'Categories' },
  { key: 'categoriesTitle', label: 'Categories Title', type: 'text', section: 'Categories' },
  { key: 'categoriesDescription', label: 'Categories Description', type: 'textarea', section: 'Categories' },
  { key: 'aboutTitle', label: 'About Title', type: 'text', section: 'About' },
  { key: 'aboutParagraph1', label: 'About Paragraph 1', type: 'textarea', section: 'About' },
  { key: 'aboutParagraph2', label: 'About Paragraph 2', type: 'textarea', section: 'About' },
  { key: 'footerQuote', label: 'Footer Quote', type: 'text', section: 'Footer' },
];

export default function Dashboard() {
  const {
    projects,
    siteContent: cloudContent,
    addProject,
    updateProject,
    deleteProject,
    resetProjects,
    updateContent,
    resetContent,
  } = useData();

  const [activeTab, setActiveTab] = useState<Tab>('projects');
  const [editingProject, setEditingProject] = useState<DashboardProject>(emptyProject);
  const [isEditing, setIsEditing] = useState(false);
  const [editId, setEditId] = useState<string | null>(null);
  const [showForm, setShowForm] = useState(false);
  const [filterCategory, setFilterCategory] = useState<string>('all');
  const [tagInput, setTagInput] = useState('');
  const [toolInput, setToolInput] = useState('');
  const [previewProject, setPreviewProject] = useState<Project | null>(null);
  const [saving, setSaving] = useState(false);

  // Local editable copy of site content
  const [siteContent, setSiteContentState] = useState<SiteContent>(cloudContent);
  const [contentSaved, setContentSaved] = useState(false);

  // Settings state
  const [currentPassword, setCurrentPassword] = useState('');
  const [newPassword, setNewPassword] = useState('');
  const [confirmPassword, setConfirmPassword] = useState('');
  const [settingsMessage, setSettingsMessage] = useState<{ type: 'success' | 'error'; text: string } | null>(null);

  const { signOut, changePassword, getCredentials } = useAuth();
  const navigate = useNavigate();

  // Sync local state when cloud content loads/changes
  useEffect(() => {
    setSiteContentState(cloudContent);
  }, [cloudContent]);

  // --- Project handlers ---
  async function handleSave() {
    if (!editingProject.title.trim()) return;
    setSaving(true);
    try {
      if (editId) {
        await updateProject(editId, editingProject as Partial<Project>);
      } else {
        await addProject(editingProject as Omit<Project, 'id'>);
      }
      resetForm();
    } finally {
      setSaving(false);
    }
  }

  function handleEdit(project: Project) {
    setEditingProject({ ...project }); setEditId(project.id); setIsEditing(true);
    setShowForm(true); setTagInput(project.tags.join(', ')); setToolInput(project.tools.join(', '));
  }

  async function handleDelete(id: string) {
    if (confirm('Delete this project?')) await deleteProject(id);
  }

  async function handleReset() {
    if (confirm('Reset all projects to defaults?')) await resetProjects();
  }

  function resetForm() {
    setEditingProject(emptyProject); setEditId(null); setIsEditing(false);
    setShowForm(false); setTagInput(''); setToolInput('');
  }

  function updateField<K extends keyof DashboardProject>(key: K, value: DashboardProject[K]) {
    setEditingProject((prev) => ({ ...prev, [key]: value }));
  }

  function parseListInput(input: string): string[] {
    return input.split(',').map((s) => s.trim()).filter(Boolean);
  }

  // --- Site content handlers ---
  function updateContentField(key: keyof SiteContent, value: string) {
    setSiteContentState((prev) => ({ ...prev, [key]: value }));
  }

  async function saveSiteContent() {
    setSaving(true);
    try {
      await updateContent(siteContent);
      setContentSaved(true);
      setTimeout(() => setContentSaved(false), 2000);
    } finally {
      setSaving(false);
    }
  }

  async function handleResetContent() {
    if (confirm('Reset all site content to defaults?')) {
      await resetContent();
      setSiteContentState(defaultContent);
    }
  }

  // --- Settings handlers ---
  function handleChangePassword() {
    setSettingsMessage(null);
    if (!currentPassword.trim() || !newPassword.trim() || !confirmPassword.trim()) {
      setSettingsMessage({ type: 'error', text: 'All fields are required.' }); return;
    }
    if (newPassword.length < 4) {
      setSettingsMessage({ type: 'error', text: 'New password must be at least 4 characters.' }); return;
    }
    if (newPassword !== confirmPassword) {
      setSettingsMessage({ type: 'error', text: 'New passwords do not match.' }); return;
    }
    const success = changePassword(currentPassword, newPassword);
    if (success) {
      setSettingsMessage({ type: 'success', text: 'Password changed successfully!' });
      setCurrentPassword(''); setNewPassword(''); setConfirmPassword('');
    } else {
      setSettingsMessage({ type: 'error', text: 'Current password is incorrect.' });
    }
    setTimeout(() => setSettingsMessage(null), 4000);
  }

  const filteredProjects = filterCategory === 'all' ? projects : projects.filter((p) => p.category === filterCategory);

  const tabs: { id: Tab; label: string; icon: React.ElementType }[] = [
    { id: 'projects', label: 'Projects', icon: LayoutDashboard },
    { id: 'site-content', label: 'Site Content', icon: Type },
    { id: 'contact-details', label: 'Contact Details', icon: ContactIcon },
    { id: 'settings', label: 'Settings', icon: Lock },
  ];

  const inputClass = "w-full bg-black/40 border border-white/10 rounded-lg px-4 py-2.5 text-white font-['Rajdhani'] text-sm focus:outline-none focus:border-[#00e676]/50 transition-colors";

  return (
    <div className="min-h-screen bg-[#0a0e1a] pt-20 pb-12 px-4">
      <div className="max-w-7xl mx-auto">
        {/* Header */}
        <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4 mb-6">
          <div>
            <div className="flex items-center gap-3 mb-2">
              <div className="relative">
                <Shield className="h-8 w-8 text-[#00e676]" />
                <div className="absolute inset-0 bg-[#00e676]/20 blur-lg rounded-full" />
              </div>
              <h1 className="font-['Orbitron'] text-2xl sm:text-3xl font-bold text-white tracking-wider">
                COMMAND <span className="text-[#00e676]">CENTER</span>
              </h1>
            </div>
            <p className="font-['Rajdhani'] text-gray-500 text-sm">Manage your portfolio, site content, and settings.</p>
          </div>
          <div className="flex items-center gap-3">
            {saving && <Loader2 className="h-4 w-4 text-[#00e676] animate-spin" />}
            <button onClick={() => { signOut(); navigate('/'); }} className="flex items-center gap-2 font-['Orbitron'] text-[10px] tracking-wider px-4 py-2 rounded-lg border border-red-400/30 text-red-400 hover:bg-red-400/10 transition-colors">
              <LogOut className="h-3.5 w-3.5" /> SIGN OUT
            </button>
          </div>
        </div>

        {/* Tabs */}
        <div className="flex gap-2 mb-6 overflow-x-auto pb-1">
          {tabs.map((tab) => {
            const Icon = tab.icon;
            const isActive = activeTab === tab.id;
            return (
              <button key={tab.id} onClick={() => setActiveTab(tab.id)}
                className={`flex items-center gap-2 font-['Orbitron'] text-[10px] tracking-wider px-5 py-2.5 rounded-lg border transition-all duration-300 whitespace-nowrap ${
                  isActive ? 'border-[#00e676]/40 bg-[#00e676]/10 text-[#00e676]' : 'border-white/5 text-gray-500 hover:text-gray-300 hover:border-white/10'
                }`}>
                <Icon className="h-3.5 w-3.5" />{tab.label.toUpperCase()}
              </button>
            );
          })}
        </div>

        {/* PROJECTS TAB */}
        {activeTab === 'projects' && (
          <>
            <div className="flex items-center gap-3 mb-6">
              <button onClick={handleReset} className="flex items-center gap-2 font-['Orbitron'] text-[10px] tracking-wider px-4 py-2 rounded-lg border border-yellow-500/30 text-yellow-500 hover:bg-yellow-500/10 transition-colors">
                <RotateCcw className="h-3.5 w-3.5" /> RESET
              </button>
              <button onClick={() => { resetForm(); setShowForm(true); }} className="flex items-center gap-2 font-['Orbitron'] text-[10px] tracking-wider px-5 py-2.5 rounded-lg bg-[#00e676] text-black font-bold hover:bg-[#00e676]/90 transition-colors shadow-[0_0_20px_rgba(0,230,118,0.3)]">
                <Plus className="h-4 w-4" /> NEW PROJECT
              </button>
            </div>

            <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-6 gap-3 mb-8">
              {categories.map((cat) => {
                const count = projects.filter((p) => p.category === cat.slug).length;
                return (
                  <div key={cat.slug}
                    className={`rounded-xl border p-3 text-center cursor-pointer transition-all duration-300 ${filterCategory === cat.slug ? 'border-[var(--c)]/50 shadow-[0_0_20px_var(--g)]' : 'border-white/5 hover:border-white/10'}`}
                    style={{ '--c': cat.color, '--g': cat.glowColor, background: filterCategory === cat.slug ? `${cat.color}08` : 'transparent' } as React.CSSProperties}
                    onClick={() => setFilterCategory(filterCategory === cat.slug ? 'all' : cat.slug)}>
                    <div className="font-['Orbitron'] text-xl font-bold" style={{ color: cat.color }}>{count}</div>
                    <div className="font-['Rajdhani'] text-[10px] text-gray-500 tracking-wider">{cat.title.split(' ')[0].toUpperCase()}</div>
                  </div>
                );
              })}
            </div>

            <AnimatePresence>
              {showForm && (
                <motion.div initial={{ opacity: 0, height: 0 }} animate={{ opacity: 1, height: 'auto' }} exit={{ opacity: 0, height: 0 }} className="mb-8 overflow-hidden">
                  <div className="rounded-2xl border border-[#00e676]/20 bg-gradient-to-br from-[#111827] to-[#0a0e1a] p-6 sm:p-8">
                    <div className="flex items-center justify-between mb-6">
                      <h2 className="font-['Orbitron'] text-lg font-bold text-[#00e676] tracking-wider">{isEditing ? 'MODIFY PROJECT' : 'NEW TRANSMISSION'}</h2>
                      <button onClick={resetForm} className="text-gray-500 hover:text-white transition-colors"><X className="h-5 w-5" /></button>
                    </div>
                    <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                      <div className="sm:col-span-2"><label className="block font-['Orbitron'] text-[10px] tracking-widest text-gray-500 mb-1.5">PROJECT TITLE *</label><input type="text" value={editingProject.title} onChange={(e) => updateField('title', e.target.value)} className={inputClass} placeholder="Enter project title..." /></div>
                      <div><label className="block font-['Orbitron'] text-[10px] tracking-widest text-gray-500 mb-1.5">CATEGORY *</label><div className="relative"><select value={editingProject.category} onChange={(e) => updateField('category', e.target.value as CategorySlug)} className={`${inputClass} appearance-none`}>{categories.map((cat) => (<option key={cat.slug} value={cat.slug}>{cat.title}</option>))}</select><ChevronDown className="absolute right-3 top-1/2 -translate-y-1/2 h-4 w-4 text-gray-500 pointer-events-none" /></div></div>
                      <div><label className="block font-['Orbitron'] text-[10px] tracking-widest text-gray-500 mb-1.5">DATE</label><input type="date" value={editingProject.date} onChange={(e) => updateField('date', e.target.value)} className={inputClass} /></div>
                      <div><label className="block font-['Orbitron'] text-[10px] tracking-widest text-gray-500 mb-1.5">CLIENT</label><input type="text" value={editingProject.client || ''} onChange={(e) => updateField('client', e.target.value)} className={inputClass} placeholder="Client name (optional)" /></div>
                      <div><label className="block font-['Orbitron'] text-[10px] tracking-widest text-gray-500 mb-1.5">IMAGE URL</label><input type="text" value={editingProject.imageUrl} onChange={(e) => updateField('imageUrl', e.target.value)} className={inputClass} placeholder="https://example.com/image.jpg" /></div>
                      <div><label className="block font-['Orbitron'] text-[10px] tracking-widest text-gray-500 mb-1.5">PROJECT LINK</label><input type="text" value={editingProject.link || ''} onChange={(e) => updateField('link', e.target.value)} className={inputClass} placeholder="https://behance.net/..." /></div>
                      <div><label className="block font-['Orbitron'] text-[10px] tracking-widest text-gray-500 mb-1.5">TAGS (comma separated)</label><input type="text" value={tagInput} onChange={(e) => { setTagInput(e.target.value); updateField('tags', parseListInput(e.target.value)); }} className={inputClass} placeholder="3D Model, River, Commercial" /></div>
                      <div><label className="block font-['Orbitron'] text-[10px] tracking-widest text-gray-500 mb-1.5">TOOLS (comma separated)</label><input type="text" value={toolInput} onChange={(e) => { setToolInput(e.target.value); updateField('tools', parseListInput(e.target.value)); }} className={inputClass} placeholder="AutoCAD, SolidWorks, Figma" /></div>
                      <div className="sm:col-span-2"><label className="block font-['Orbitron'] text-[10px] tracking-widest text-gray-500 mb-1.5">SHORT DESCRIPTION *</label><input type="text" value={editingProject.description} onChange={(e) => updateField('description', e.target.value)} className={inputClass} placeholder="Brief description..." /></div>
                      <div className="sm:col-span-2"><label className="block font-['Orbitron'] text-[10px] tracking-widest text-gray-500 mb-1.5">FULL DETAILS</label><textarea value={editingProject.details} onChange={(e) => updateField('details', e.target.value)} rows={5} className={`${inputClass} resize-y`} placeholder="Detailed description..." /></div>
                    </div>
                    <div className="mt-6 flex items-center gap-3">
                      <button onClick={handleSave} disabled={!editingProject.title.trim() || saving} className="flex items-center gap-2 font-['Orbitron'] text-xs tracking-wider px-6 py-3 rounded-lg bg-[#00e676] text-black font-bold hover:bg-[#00e676]/90 transition-colors shadow-[0_0_20px_rgba(0,230,118,0.3)] disabled:opacity-40 disabled:cursor-not-allowed">
                        {saving ? <Loader2 className="h-4 w-4 animate-spin" /> : <Save className="h-4 w-4" />}
                        {isEditing ? 'UPDATE PROJECT' : 'SAVE PROJECT'}
                      </button>
                      <button onClick={resetForm} className="font-['Orbitron'] text-xs tracking-wider px-5 py-3 rounded-lg border border-white/10 text-gray-400 hover:text-white transition-colors">CANCEL</button>
                    </div>
                  </div>
                </motion.div>
              )}
            </AnimatePresence>

            <div className="rounded-2xl border border-white/5 bg-gradient-to-br from-[#111827] to-[#0a0e1a] overflow-hidden">
              <div className="hidden sm:grid grid-cols-12 gap-4 px-6 py-3 border-b border-white/5 font-['Orbitron'] text-[10px] tracking-widest text-gray-600">
                <div className="col-span-4">PROJECT</div><div className="col-span-2">CATEGORY</div><div className="col-span-2">DATE</div><div className="col-span-2">TOOLS</div><div className="col-span-2 text-right">ACTIONS</div>
              </div>
              {filteredProjects.length === 0 ? (
                <div className="py-16 text-center"><LayoutDashboard className="h-10 w-10 text-gray-700 mx-auto mb-3" /><div className="font-['Orbitron'] text-xs text-gray-600">NO PROJECTS FOUND</div></div>
              ) : (
                <div className="divide-y divide-white/5">
                  {filteredProjects.map((project) => {
                    const cat = categories.find((c) => c.slug === project.category);
                    const color = cat?.color || '#00e676';
                    return (
                      <motion.div key={project.id} layout initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }} className="grid grid-cols-1 sm:grid-cols-12 gap-2 sm:gap-4 px-6 py-4 items-center hover:bg-white/[0.02] transition-colors">
                        <div className="sm:col-span-4"><h3 className="font-['Orbitron'] text-xs font-bold tracking-wider truncate" style={{ color }}>{project.title.toUpperCase()}</h3><p className="font-['Rajdhani'] text-xs text-gray-600 truncate mt-0.5">{project.description}</p></div>
                        <div className="sm:col-span-2"><span className="font-['Orbitron'] text-[9px] tracking-wider px-2 py-0.5 rounded-full border" style={{ color: `${color}cc`, borderColor: `${color}30`, background: `${color}08` }}>{cat?.title.split(' ')[0].toUpperCase()}</span></div>
                        <div className="sm:col-span-2 font-['Rajdhani'] text-xs text-gray-500">{new Date(project.date).toLocaleDateString('en-US', { year: 'numeric', month: 'short' })}</div>
                        <div className="sm:col-span-2 font-['Rajdhani'] text-xs text-gray-500 truncate">{project.tools.join(', ')}</div>
                        <div className="sm:col-span-2 flex items-center justify-end gap-2">
                          <button onClick={() => setPreviewProject(project)} className="p-1.5 rounded-lg border border-white/10 text-gray-500 hover:text-white hover:border-white/20 transition-colors"><Eye className="h-3.5 w-3.5" /></button>
                          <button onClick={() => handleEdit(project)} className="p-1.5 rounded-lg border border-white/10 text-gray-500 hover:text-[#00e676] hover:border-[#00e676]/30 transition-colors"><Edit3 className="h-3.5 w-3.5" /></button>
                          <button onClick={() => handleDelete(project.id)} className="p-1.5 rounded-lg border border-white/10 text-gray-500 hover:text-red-400 hover:border-red-400/30 transition-colors"><Trash2 className="h-3.5 w-3.5" /></button>
                        </div>
                      </motion.div>
                    );
                  })}
                </div>
              )}
            </div>
          </>
        )}

        {/* SITE CONTENT TAB */}
        {activeTab === 'site-content' && (
          <div className="rounded-2xl border border-[#00e676]/10 bg-gradient-to-br from-[#111827] to-[#0a0e1a] overflow-hidden">
            <div className="h-1 w-full" style={{ background: 'linear-gradient(90deg, transparent, #00e676, transparent)' }} />
            <div className="p-6 sm:p-8">
              <div className="flex items-center justify-between mb-6">
                <div className="flex items-center gap-3"><Type className="h-5 w-5 text-[#00e676]" /><h2 className="font-['Orbitron'] text-lg font-bold text-white tracking-wider">SITE <span className="text-[#00e676]">CONTENT</span></h2></div>
                <div className="flex items-center gap-3">
                  <button onClick={handleResetContent} className="flex items-center gap-2 font-['Orbitron'] text-[10px] tracking-wider px-4 py-2 rounded-lg border border-yellow-500/30 text-yellow-500 hover:bg-yellow-500/10 transition-colors"><RotateCcw className="h-3.5 w-3.5" />RESET</button>
                  <button onClick={saveSiteContent} disabled={saving} className="flex items-center gap-2 font-['Orbitron'] text-[10px] tracking-wider px-5 py-2.5 rounded-lg bg-[#00e676] text-black font-bold hover:bg-[#00e676]/90 transition-colors shadow-[0_0_20px_rgba(0,230,118,0.3)] disabled:opacity-60">
                    {saving ? <Loader2 className="h-4 w-4 animate-spin" /> : <Save className="h-4 w-4" />}
                    {contentSaved ? 'SAVED ✓' : 'SAVE ALL'}
                  </button>
                </div>
              </div>
              <p className="font-['Rajdhani'] text-gray-500 text-sm mb-8">Edit any text on your website. Changes save to Firebase and reflect everywhere instantly.</p>
              {['Hero', 'Categories', 'About', 'Footer'].map((section) => {
                const fields = contentFields.filter((f) => f.section === section);
                return (
                  <div key={section} className="mb-8">
                    <div className="font-['Orbitron'] text-[10px] tracking-[0.3em] text-[#00e676]/60 mb-4 border-b border-[#00e676]/10 pb-2">{section.toUpperCase()}</div>
                    <div className="space-y-4">
                      {fields.map((field) => (
                        <div key={field.key}>
                          <label className="block font-['Orbitron'] text-[10px] tracking-widest text-gray-500 mb-1.5">{field.label.toUpperCase()}</label>
                          {field.type === 'textarea' ? (
                            <textarea value={siteContent[field.key]} onChange={(e) => updateContentField(field.key, e.target.value)} rows={3} className={`${inputClass} resize-y`} />
                          ) : (
                            <input type="text" value={siteContent[field.key]} onChange={(e) => updateContentField(field.key, e.target.value)} className={inputClass} />
                          )}
                        </div>
                      ))}
                    </div>
                  </div>
                );
              })}
            </div>
          </div>
        )}

        {/* CONTACT DETAILS TAB */}
        {activeTab === 'contact-details' && (
          <div className="rounded-2xl border border-[#00e676]/10 bg-gradient-to-br from-[#111827] to-[#0a0e1a] overflow-hidden">
            <div className="h-1 w-full" style={{ background: 'linear-gradient(90deg, transparent, #00bcd4, transparent)' }} />
            <div className="p-6 sm:p-8">
              <div className="flex items-center justify-between mb-6">
                <div className="flex items-center gap-3"><ContactIcon className="h-5 w-5 text-[#00bcd4]" /><h2 className="font-['Orbitron'] text-lg font-bold text-white tracking-wider">CONTACT <span className="text-[#00bcd4]">DETAILS</span></h2></div>
                <button onClick={saveSiteContent} disabled={saving} className="flex items-center gap-2 font-['Orbitron'] text-[10px] tracking-wider px-5 py-2.5 rounded-lg bg-[#00e676] text-black font-bold hover:bg-[#00e676]/90 transition-colors shadow-[0_0_20px_rgba(0,230,118,0.3)] disabled:opacity-60">
                  {saving ? <Loader2 className="h-4 w-4 animate-spin" /> : <Save className="h-4 w-4" />}
                  {contentSaved ? 'SAVED ✓' : 'SAVE ALL'}
                </button>
              </div>
              <p className="font-['Rajdhani'] text-gray-500 text-sm mb-8">Update your contact information. Changes reflect on the Contact page and across the site.</p>
              <div className="space-y-5">
                <div><label className="block font-['Orbitron'] text-[10px] tracking-widest text-gray-500 mb-1.5">EMAIL ADDRESS</label><input type="text" value={siteContent.contactEmail} onChange={(e) => { updateContentField('contactEmail', e.target.value); updateContentField('contactEmailHref', `mailto:${e.target.value}`); }} className={inputClass} placeholder="your@email.com" /></div>
                <div><label className="block font-['Orbitron'] text-[10px] tracking-widest text-gray-500 mb-1.5">PHONE NUMBER</label><input type="text" value={siteContent.contactPhone} onChange={(e) => { updateContentField('contactPhone', e.target.value); const d = e.target.value.replace(/\D/g, ''); updateContentField('contactPhoneHref', `tel:+${d}`); }} className={inputClass} placeholder="+91 XXXXX XXXXX" /></div>
                <div><label className="block font-['Orbitron'] text-[10px] tracking-widest text-gray-500 mb-1.5">LOCATION</label><input type="text" value={siteContent.contactLocation} onChange={(e) => updateContentField('contactLocation', e.target.value)} className={inputClass} placeholder="City, Country" /></div>
                <div><label className="block font-['Orbitron'] text-[10px] tracking-widest text-gray-500 mb-1.5">LOCATION DESCRIPTION</label><input type="text" value={siteContent.contactLocationDescription} onChange={(e) => updateContentField('contactLocationDescription', e.target.value)} className={inputClass} placeholder="Available for remote & on-site work" /></div>
                <div><label className="block font-['Orbitron'] text-[10px] tracking-widest text-gray-500 mb-1.5">BEHANCE URL</label><input type="text" value={siteContent.behanceUrl} onChange={(e) => updateContentField('behanceUrl', e.target.value)} className={inputClass} placeholder="https://www.behance.net/..." /></div>
                <div><label className="block font-['Orbitron'] text-[10px] tracking-widest text-gray-500 mb-1.5">LINKEDIN URL</label><input type="text" value={siteContent.linkedinUrl} onChange={(e) => updateContentField('linkedinUrl', e.target.value)} className={inputClass} placeholder="https://linkedin.com/in/..." /></div>
              </div>
            </div>
          </div>
        )}

        {/* SETTINGS TAB */}
        {activeTab === 'settings' && (
          <div className="rounded-2xl border border-[#00e676]/10 bg-gradient-to-br from-[#111827] to-[#0a0e1a] overflow-hidden">
            <div className="h-1 w-full" style={{ background: 'linear-gradient(90deg, transparent, #e040fb, transparent)' }} />
            <div className="p-6 sm:p-8">
              <div className="flex items-center gap-3 mb-8">
                <Lock className="h-5 w-5 text-[#e040fb]" />
                <h2 className="font-['Orbitron'] text-lg font-bold text-white tracking-wider">ACCOUNT <span className="text-[#e040fb]">SETTINGS</span></h2>
              </div>
              <div className="rounded-xl border border-white/5 bg-black/20 p-4 mb-8">
                <div className="font-['Orbitron'] text-[10px] tracking-widest text-gray-500 mb-2">LOGGED IN AS</div>
                <div className="font-['Rajdhani'] text-white text-sm">{getCredentials().username}</div>
              </div>
              {settingsMessage && (
                <motion.div initial={{ opacity: 0, y: -5 }} animate={{ opacity: 1, y: 0 }}
                  className={`flex items-center gap-2 rounded-lg px-4 py-3 mb-6 ${settingsMessage.type === 'success' ? 'bg-[#00e676]/10 border border-[#00e676]/20 text-[#00e676]' : 'bg-red-400/10 border border-red-400/20 text-red-400'}`}>
                  {settingsMessage.type === 'success' ? <CheckCircle className="h-4 w-4 flex-shrink-0" /> : <AlertTriangle className="h-4 w-4 flex-shrink-0" />}
                  <span className="font-['Rajdhani'] text-sm">{settingsMessage.text}</span>
                </motion.div>
              )}
              <div className="mb-8">
                <div className="font-['Orbitron'] text-[10px] tracking-[0.3em] text-[#e040fb]/60 mb-4 border-b border-[#e040fb]/10 pb-2">CHANGE PASSWORD</div>
                <div className="space-y-4 max-w-md">
                  <div><label className="block font-['Orbitron'] text-[10px] tracking-widest text-gray-500 mb-1.5">CURRENT PASSWORD</label><input type="password" value={currentPassword} onChange={(e) => setCurrentPassword(e.target.value)} className={inputClass} placeholder="Enter current password" /></div>
                  <div><label className="block font-['Orbitron'] text-[10px] tracking-widest text-gray-500 mb-1.5">NEW PASSWORD</label><input type="password" value={newPassword} onChange={(e) => setNewPassword(e.target.value)} className={inputClass} placeholder="Min 4 characters" /></div>
                  <div><label className="block font-['Orbitron'] text-[10px] tracking-widest text-gray-500 mb-1.5">CONFIRM NEW PASSWORD</label><input type="password" value={confirmPassword} onChange={(e) => setConfirmPassword(e.target.value)} className={inputClass} placeholder="Re-enter new password" /></div>
                  <button onClick={handleChangePassword} className="flex items-center gap-2 font-['Orbitron'] text-[10px] tracking-wider px-6 py-3 rounded-lg bg-[#e040fb] text-white font-bold hover:bg-[#e040fb]/90 transition-colors shadow-[0_0_20px_rgba(224,64,251,0.3)]">
                    <Lock className="h-4 w-4" />CHANGE PASSWORD
                  </button>
                </div>
              </div>
              <div className="rounded-xl border border-[#00e676]/10 bg-[#00e676]/5 p-4">
                <div className="font-['Orbitron'] text-[10px] tracking-widest text-[#00e676]/60 mb-2">CLOUD SYNC STATUS</div>
                <p className="font-['Rajdhani'] text-gray-400 text-sm">✅ Connected to Firebase Firestore. Your projects and content sync instantly across all devices worldwide.</p>
              </div>
            </div>
          </div>
        )}
      </div>

      {/* Preview Modal */}
      <AnimatePresence>
        {previewProject && (
          <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }} className="fixed inset-0 z-[100] flex items-center justify-center p-4" onClick={() => setPreviewProject(null)}>
            <div className="absolute inset-0 bg-black/80 backdrop-blur-sm" />
            <motion.div initial={{ scale: 0.9, opacity: 0 }} animate={{ scale: 1, opacity: 1 }} exit={{ scale: 0.9, opacity: 0 }} className="relative w-full max-w-2xl max-h-[80vh] overflow-y-auto rounded-2xl border border-white/10 bg-gradient-to-br from-[#111827] to-[#0a0e1a] p-8" onClick={(e: React.MouseEvent) => e.stopPropagation()}>
              <button onClick={() => setPreviewProject(null)} className="absolute top-4 right-4 text-gray-500 hover:text-white"><X className="h-5 w-5" /></button>
              <h2 className="font-['Orbitron'] text-lg font-bold text-white tracking-wider mb-4">{previewProject.title.toUpperCase()}</h2>
              <p className="font-['Rajdhani'] text-gray-400 text-sm leading-relaxed">{previewProject.details}</p>
              <div className="mt-4 flex flex-wrap gap-2">{previewProject.tools.map((tool) => (<span key={tool} className="font-['Rajdhani'] text-xs px-2 py-0.5 rounded bg-white/5 border border-white/10 text-gray-400">{tool}</span>))}</div>
            </motion.div>
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
}
