import { useState } from 'react';
import { useParams, Link } from 'react-router-dom';
import { ArrowLeft } from 'lucide-react';
import { motion } from 'framer-motion';
import ProjectCard from '../components/ProjectCard';
import ProjectModal from '../components/ProjectModal';
import OmnitrixSymbol from '../components/OmnitrixSymbol';
import { categories } from '../lib/data';
import { getProjectsByCategory } from '../lib/store';
import { Project } from '../types';

export default function CategoryPage() {
  const { slug } = useParams<{ slug: string }>();
  const [selectedProject, setSelectedProject] = useState<Project | null>(null);

  const category = categories.find((c) => c.slug === slug);
  const projects = slug ? getProjectsByCategory(slug) : [];

  if (!category) {
    return (
      <div className="min-h-screen bg-[#0a0e1a] flex items-center justify-center">
        <div className="text-center">
          <OmnitrixSymbol size={80} animate={false} />
          <h2 className="font-['Orbitron'] text-xl text-white mt-6">DIMENSION NOT FOUND</h2>
          <p className="font-['Rajdhani'] text-gray-500 mt-2">This alien form doesn't exist yet.</p>
          <Link
            to="/"
            className="inline-block mt-6 font-['Orbitron'] text-xs tracking-wider text-[#00e676] border border-[#00e676]/30 px-4 py-2 rounded-lg hover:bg-[#00e676]/10 transition-colors"
          >
            ← RETURN HOME
          </Link>
        </div>
      </div>
    );
  }

  const color = category.color;

  return (
    <div className="min-h-screen bg-[#0a0e1a]">
      {/* Header */}
      <section className="relative pt-24 pb-12 px-4">
        <div
          className="absolute inset-0"
          style={{
            backgroundImage: `
              radial-gradient(ellipse at 50% 0%, ${category.glowColor.replace('0.4', '0.1')} 0%, transparent 60%)
            `,
          }}
        />

        <div className="relative z-10 max-w-7xl mx-auto">
          <Link
            to="/"
            className="inline-flex items-center gap-2 font-['Orbitron'] text-xs tracking-wider text-gray-500 hover:text-[#00e676] transition-colors mb-8"
          >
            <ArrowLeft className="h-4 w-4" />
            ALL DIMENSIONS
          </Link>

          <div className="flex items-center gap-6 mb-4">
            <div
              className="inline-flex items-center justify-center rounded-xl p-4"
              style={{
                background: `${color}15`,
                boxShadow: `0 0 30px ${category.glowColor}`,
              }}
            >
              <OmnitrixSymbol size={50} animate={false} />
            </div>
            <div>
              <div className="font-['Orbitron'] text-[10px] tracking-[0.3em] text-gray-500 mb-1">
                // {slug?.toUpperCase()}
              </div>
              <h1
                className="font-['Orbitron'] text-3xl sm:text-4xl font-bold tracking-wider"
                style={{ color }}
              >
                {category.title.toUpperCase()}
              </h1>
            </div>
          </div>

          <p className="font-['Rajdhani'] text-gray-400 max-w-2xl text-lg">
            {category.description}
          </p>

          <div className="mt-4 flex items-center gap-3">
            <div
              className="h-1 w-16 rounded-full"
              style={{ background: `linear-gradient(90deg, ${color}, transparent)` }}
            />
            <span className="font-['Orbitron'] text-xs tracking-wider text-gray-600">
              {projects.length} PROJECT{projects.length !== 1 ? 'S' : ''} FOUND
            </span>
          </div>
        </div>
      </section>

      {/* Projects grid */}
      <section className="px-4 pb-24">
        <div className="max-w-7xl mx-auto">
          {projects.length === 0 ? (
            <div className="text-center py-20">
              <div className="font-['Orbitron'] text-sm text-gray-600 mb-4">NO PROJECTS YET</div>
              <p className="font-['Rajdhani'] text-gray-500">
                This dimension awaits its first creation. Check back soon!
              </p>
            </div>
          ) : (
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
              {projects.map((project, i) => (
                <ProjectCard
                  key={project.id}
                  project={project}
                  index={i}
                  onClick={() => setSelectedProject(project)}
                />
              ))}
            </div>
          )}
        </div>
      </section>

      {/* Project modal */}
      <ProjectModal
        project={selectedProject}
        onClose={() => setSelectedProject(null)}
      />
    </div>
  );
}
