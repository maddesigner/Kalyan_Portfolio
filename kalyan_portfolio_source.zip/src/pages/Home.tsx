import { Link } from 'react-router-dom';
import { motion } from 'framer-motion';
import { useState, useEffect } from 'react';
import { ArrowDown, Sparkles } from 'lucide-react';
import { useAuth } from '../lib/auth';
import { getSiteContent } from '../lib/siteContent';
import OmnitrixSymbol from '../components/OmnitrixSymbol';
import CategoryCard from '../components/CategoryCard';
import { categories } from '../lib/data';
import { getProjects } from '../lib/store';

export default function Home() {
  const [, setTick] = useState(0);
  const { isAuthenticated, signOut } = useAuth();

  // Re-render when localStorage updates
  useEffect(() => {
    const handler = () => setTick((t) => t + 1);
    window.addEventListener('storage', handler);
    return () => {
      window.removeEventListener('storage', handler);
    };
  }, []);

  const projects = getProjects();
  const projectCount = projects.length;
  const content = getSiteContent();

  return (
    <div className="min-h-screen">
      {/* HERO SECTION */}
      <section className="relative min-h-[90vh] flex items-center justify-center overflow-hidden">
        <div className="absolute inset-0 bg-[#0a0e1a]" />
        <div
          className="absolute inset-0"
          style={{
            backgroundImage: `
              radial-gradient(ellipse at 20% 50%, rgba(0,230,118,0.08) 0%, transparent 50%),
              radial-gradient(ellipse at 80% 20%, rgba(0,188,212,0.06) 0%, transparent 50%),
              radial-gradient(ellipse at 50% 80%, rgba(224,64,251,0.04) 0%, transparent 50%)
            `,
          }}
        />

        <div
          className="absolute inset-0 opacity-[0.03]"
          style={{
            backgroundImage: `
              linear-gradient(rgba(0,230,118,0.3) 1px, transparent 1px),
              linear-gradient(90deg, rgba(0,230,118,0.3) 1px, transparent 1px)
            `,
            backgroundSize: '60px 60px',
          }}
        />

        <div className="absolute inset-0 overflow-hidden pointer-events-none">
          <motion.div
            className="absolute top-1/4 left-0 w-full h-px bg-gradient-to-r from-transparent via-[#00e676]/20 to-transparent"
            animate={{ x: ['-100%', '100%'] }}
            transition={{ duration: 8, repeat: Infinity, ease: 'linear' }}
          />
          <motion.div
            className="absolute top-2/3 left-0 w-full h-px bg-gradient-to-r from-transparent via-[#00bcd4]/15 to-transparent"
            animate={{ x: ['100%', '-100%'] }}
            transition={{ duration: 12, repeat: Infinity, ease: 'linear' }}
          />
        </div>

        <div className="relative z-10 text-center px-4 max-w-4xl mx-auto">
          <motion.div
            initial={{ scale: 0, rotate: -180 }}
            animate={{ scale: 1, rotate: 0 }}
            transition={{ type: 'spring', damping: 15, stiffness: 100, delay: 0.2 }}
            className="mb-8 flex justify-center"
          >
            <OmnitrixSymbol size={100} />
          </motion.div>

          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.5 }}
            className="flex items-center justify-center gap-2 mb-4"
          >
            <Sparkles className="h-4 w-4 text-[#00e676]" />
            <span className="font-['Orbitron'] text-xs tracking-[0.3em] text-[#00e676]/80">
              {content.heroSubtitle}
            </span>
            <Sparkles className="h-4 w-4 text-[#00e676]" />
          </motion.div>

          <motion.h1
            initial={{ opacity: 0, y: 30 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.7 }}
            className="font-['Orbitron'] text-4xl sm:text-5xl md:text-7xl font-black tracking-wider text-white mb-6 leading-tight"
          >
            {content.heroTitleLine1}
            <br />
            <span className="text-[#00e676]">{content.heroTitleLine2}</span>
          </motion.h1>

          <motion.p
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.9 }}
            className="font-['Rajdhani'] text-lg sm:text-xl text-gray-400 max-w-2xl mx-auto mb-8 leading-relaxed"
          >
            {content.heroTagline}
          </motion.p>

          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            transition={{ delay: 1.1 }}
            className="flex items-center justify-center gap-8 mb-12"
          >
            <div className="text-center">
              <div className="font-['Orbitron'] text-2xl font-bold text-[#00e676]">{projectCount}</div>
              <div className="font-['Rajdhani'] text-xs text-gray-500 tracking-wider">PROJECTS</div>
            </div>
            <div className="w-px h-8 bg-[#00e676]/20" />
            <div className="text-center">
              <div className="font-['Orbitron'] text-2xl font-bold text-[#00bcd4]">5</div>
              <div className="font-['Rajdhani'] text-xs text-gray-500 tracking-wider">DISCIPLINES</div>
            </div>
            <div className="w-px h-8 bg-[#00e676]/20" />
            <div className="text-center">
              <div className="font-['Orbitron'] text-2xl font-bold text-[#e040fb]">∞</div>
              <div className="font-['Rajdhani'] text-xs text-gray-500 tracking-wider">CREATIVITY</div>
            </div>
          </motion.div>

          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            transition={{ delay: 1.5 }}
            className="flex flex-col items-center gap-2"
          >
            <span className="font-['Orbitron'] text-[10px] tracking-[0.3em] text-gray-600">
              {content.scrollIndicator}
            </span>
            <motion.div
              animate={{ y: [0, 8, 0] }}
              transition={{ duration: 2, repeat: Infinity }}
            >
              <ArrowDown className="h-5 w-5 text-[#00e676]/50" />
            </motion.div>
          </motion.div>
        </div>
      </section>

      {/* CATEGORIES SECTION */}
      <section className="relative py-24 px-4">
        <div className="absolute inset-0 bg-[#0a0e1a]" />
        <div
          className="absolute inset-0"
          style={{
            backgroundImage: `
              radial-gradient(ellipse at 50% 0%, rgba(0,230,118,0.05) 0%, transparent 60%)
            `,
          }}
        />

        <div className="relative z-10 max-w-7xl mx-auto">
          <div className="text-center mb-16">
            <div className="font-['Orbitron'] text-[10px] tracking-[0.4em] text-[#00e676]/60 mb-3">
              {content.categoriesTag}
            </div>
            <h2 className="font-['Orbitron'] text-3xl sm:text-4xl font-bold text-white tracking-wider mb-4">
              {(() => {
                const words = content.categoriesTitle.split(' ');
                const lastIdx = words.length - 1;
                return words.map((word: string, i: number) => (
                  <span key={i}>
                    {i === lastIdx ? <span className="text-[#00e676]">{word}</span> : word}
                    {i < lastIdx ? ' ' : ''}
                  </span>
                ));
              })()}
            </h2>
            <p className="font-['Rajdhani'] text-gray-400 max-w-lg mx-auto">
              {content.categoriesDescription}
            </p>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
            {categories.map((cat, i) => (
              <CategoryCard key={cat.slug} category={cat} index={i} />
            ))}
          </div>
        </div>
      </section>

      {/* ABOUT SECTION */}
      <section className="relative py-24 px-4">
        <div className="absolute inset-0 bg-[#0a0e1a]" />
        <div
          className="absolute inset-0"
          style={{
            backgroundImage: `
              radial-gradient(ellipse at 80% 50%, rgba(0,188,212,0.06) 0%, transparent 50%)
            `,
          }}
        />

        <div className="relative z-10 max-w-4xl mx-auto">
          <div className="rounded-2xl border border-[#00e676]/10 bg-gradient-to-br from-[#111827] to-[#0a0e1a] p-8 sm:p-12">
            <div className="h-1 w-24 mb-8" style={{ background: 'linear-gradient(90deg, #00e676, transparent)' }} />
            <h2 className="font-['Orbitron'] text-2xl sm:text-3xl font-bold text-white tracking-wider mb-6">
              {(() => {
                const words = content.aboutTitle.split(' ');
                const lastIdx = words.length - 1;
                return words.map((word: string, i: number) => (
                  <span key={i}>
                    {i === lastIdx ? <span className="text-[#00e676]">{word}</span> : word}
                    {i < lastIdx ? ' ' : ''}
                  </span>
                ));
              })()}
            </h2>
            <p className="font-['Rajdhani'] text-gray-300 text-lg leading-relaxed mb-6">
              {content.aboutParagraph1}
            </p>
            <p className="font-['Rajdhani'] text-gray-400 text-base leading-relaxed mb-8">
              {content.aboutParagraph2}
            </p>

            <div className="flex flex-wrap gap-4">
              <a
                href={content.behanceUrl}
                target="_blank"
                rel="noopener noreferrer"
                className="font-['Orbitron'] text-xs tracking-wider px-5 py-2.5 rounded-lg border border-[#1769ff]/30 text-[#1769ff] hover:bg-[#1769ff]/10 transition-all duration-300"
              >
                BEHANCE →
              </a>
              <a
                href={content.linkedinUrl}
                target="_blank"
                rel="noopener noreferrer"
                className="font-['Orbitron'] text-xs tracking-wider px-5 py-2.5 rounded-lg border border-[#0077b5]/30 text-[#0077b5] hover:bg-[#0077b5]/10 transition-all duration-300"
              >
                LINKEDIN →
              </a>
            </div>
          </div>
        </div>
      </section>

      {/* FOOTER */}
      <footer className="relative py-10 px-4 border-t border-[#00e676]/10">
        <div className="absolute inset-0 bg-[#0a0e1a]" />
        <div className="relative z-10 max-w-7xl mx-auto">
          <div className="flex flex-col md:flex-row items-center justify-between gap-6">
            <div className="text-center md:text-left">
              <div className="font-['Orbitron'] text-sm font-bold text-white tracking-wider mb-1">
                KALYAN<span className="text-[#00e676]">.DEV</span>
              </div>
              <div className="font-['Rajdhani'] text-xs text-gray-600">
                {content.footerQuote}
              </div>
            </div>

            <div className="flex items-center gap-4 text-[11px]">
              <a
                href={content.behanceUrl}
                target="_blank"
                rel="noopener noreferrer"
                className="font-['Rajdhani'] text-gray-600 hover:text-[#1769ff] transition-colors"
              >
                Behance
              </a>
              <span className="text-gray-800">·</span>
              <a
                href={content.linkedinUrl}
                target="_blank"
                rel="noopener noreferrer"
                className="font-['Rajdhani'] text-gray-600 hover:text-[#0077b5] transition-colors"
              >
                LinkedIn
              </a>
              <span className="text-gray-800">·</span>
              {isAuthenticated ? (
                <Link
                  to="/"
                  onClick={() => signOut()}
                  className="font-['Rajdhani'] text-gray-700 hover:text-gray-400 transition-colors"
                >
                  Sign out
                </Link>
              ) : (
                <Link
                  to="/signin"
                  className="font-['Rajdhani'] text-gray-700 hover:text-gray-400 transition-colors"
                >
                  Sign in
                </Link>
              )}
            </div>

            <div className="text-center md:text-right">
              <div className="font-['Orbitron'] text-[10px] tracking-wider text-gray-600">
                © {new Date().getFullYear()} KONDAVETI KALYAN SAI
              </div>
            </div>
          </div>
        </div>
      </footer>
    </div>
  );
}
