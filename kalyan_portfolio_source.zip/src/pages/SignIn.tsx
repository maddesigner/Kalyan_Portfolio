import { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { motion } from 'framer-motion';
import { Shield, Eye, EyeOff, AlertTriangle, Fingerprint } from 'lucide-react';
import { useAuth } from '../lib/auth';
import OmnitrixSymbol from '../components/OmnitrixSymbol';

export default function SignIn() {
  const [username, setUsername] = useState('');
  const [password, setPassword] = useState('');
  const [showPassword, setShowPassword] = useState(false);
  const [error, setError] = useState('');
  const [isLoading, setIsLoading] = useState(false);
  const { signIn } = useAuth();
  const navigate = useNavigate();

  function handleSubmit(e: React.FormEvent) {
    e.preventDefault();
    setError('');

    if (!username.trim() || !password.trim()) {
      setError('All fields are required');
      return;
    }

    setIsLoading(true);

    setTimeout(() => {
      const success = signIn(username, password);
      if (success) {
        navigate('/dashboard');
      } else {
        setError('Access denied. Invalid credentials.');
        setIsLoading(false);
      }
    }, 1200);
  }

  return (
    <div className="min-h-screen flex items-center justify-center relative overflow-hidden">
      <div className="absolute inset-0 bg-[#0a0e1a]" />
      <div
        className="absolute inset-0"
        style={{
          backgroundImage: `
            radial-gradient(ellipse at 30% 40%, rgba(0,230,118,0.08) 0%, transparent 50%),
            radial-gradient(ellipse at 70% 60%, rgba(0,188,212,0.06) 0%, transparent 50%)
          `,
        }}
      />
      <div
        className="absolute inset-0 opacity-[0.03]"
        style={{
          backgroundImage: `
            linear-gradient(rgba(0,230,118,0.3) 1px, transparent 1px),
            linear-gradient(90deg, rgba(0,230,118,0.3) 1px, transparent 1px)
          `,
          backgroundSize: '60px 60px',
        }}
      />

      <motion.div
        className="absolute left-0 right-0 h-px bg-gradient-to-r from-transparent via-[#00e676]/30 to-transparent"
        animate={{ top: ['0%', '100%'] }}
        transition={{ duration: 4, repeat: Infinity, ease: 'linear' }}
      />

      <motion.div
        initial={{ opacity: 0, y: 30, scale: 0.95 }}
        animate={{ opacity: 1, y: 0, scale: 1 }}
        transition={{ duration: 0.6 }}
        className="relative z-10 w-full max-w-md mx-4"
      >
        <div className="rounded-2xl border border-[#00e676]/15 bg-gradient-to-br from-[#111827]/95 to-[#0a0e1a]/95 backdrop-blur-xl overflow-hidden">
          <div
            className="h-1 w-full"
            style={{ background: 'linear-gradient(90deg, transparent, #00e676, transparent)' }}
          />

          <div className="p-8 sm:p-10">
            <div className="text-center mb-8">
              <motion.div
                initial={{ scale: 0 }}
                animate={{ scale: 1 }}
                transition={{ type: 'spring', damping: 12, stiffness: 100, delay: 0.3 }}
                className="flex justify-center mb-5"
              >
                <div className="relative">
                  <div className="absolute inset-0 bg-[#00e676]/20 blur-2xl rounded-full" />
                  <OmnitrixSymbol size={70} animate={false} />
                </div>
              </motion.div>

              <div className="flex items-center justify-center gap-2 mb-3">
                <Shield className="h-4 w-4 text-[#00e676]" />
                <span className="font-['Orbitron'] text-[10px] tracking-[0.3em] text-[#00e676]/70">
                  SECURE ACCESS
                </span>
                <Shield className="h-4 w-4 text-[#00e676]" />
              </div>

              <h1 className="font-['Orbitron'] text-xl sm:text-2xl font-bold text-white tracking-wider">
                COMMAND <span className="text-[#00e676]">CENTER</span>
              </h1>
              <p className="font-['Rajdhani'] text-gray-500 text-sm mt-2">
                Authorization required to access the dashboard
              </p>
            </div>

            <form onSubmit={handleSubmit} className="space-y-5">
              <div>
                <label className="block font-['Orbitron'] text-[10px] tracking-widest text-gray-500 mb-2">
                  OPERATOR ID
                </label>
                <div className="relative">
                  <input
                    type="text"
                    value={username}
                    onChange={(e) => setUsername(e.target.value)}
                    className="w-full bg-black/40 border border-white/10 rounded-lg px-4 py-3 text-white font-['Rajdhani'] text-sm focus:outline-none focus:border-[#00e676]/50 focus:shadow-[0_0_15px_rgba(0,230,118,0.1)] transition-all duration-300 placeholder-gray-700"
                    placeholder="Enter username..."
                    autoComplete="username"
                    disabled={isLoading}
                  />
                  <Fingerprint className="absolute right-3 top-1/2 -translate-y-1/2 h-4 w-4 text-gray-700" />
                </div>
              </div>

              <div>
                <label className="block font-['Orbitron'] text-[10px] tracking-widest text-gray-500 mb-2">
                  ACCESS CODE
                </label>
                <div className="relative">
                  <input
                    type={showPassword ? 'text' : 'password'}
                    value={password}
                    onChange={(e) => setPassword(e.target.value)}
                    className="w-full bg-black/40 border border-white/10 rounded-lg px-4 py-3 pr-11 text-white font-['Rajdhani'] text-sm focus:outline-none focus:border-[#00e676]/50 focus:shadow-[0_0_15px_rgba(0,230,118,0.1)] transition-all duration-300 placeholder-gray-700"
                    placeholder="Enter password..."
                    autoComplete="current-password"
                    disabled={isLoading}
                  />
                  <button
                    type="button"
                    onClick={() => setShowPassword(!showPassword)}
                    className="absolute right-3 top-1/2 -translate-y-1/2 text-gray-600 hover:text-gray-400 transition-colors"
                  >
                    {showPassword ? <EyeOff className="h-4 w-4" /> : <Eye className="h-4 w-4" />}
                  </button>
                </div>
              </div>

              {error && (
                <motion.div
                  initial={{ opacity: 0, y: -5 }}
                  animate={{ opacity: 1, y: 0 }}
                  className="flex items-center gap-2 text-red-400 bg-red-400/10 border border-red-400/20 rounded-lg px-4 py-2.5"
                >
                  <AlertTriangle className="h-4 w-4 flex-shrink-0" />
                  <span className="font-['Rajdhani'] text-sm">{error}</span>
                </motion.div>
              )}

              <button
                type="submit"
                disabled={isLoading}
                className="w-full flex items-center justify-center gap-2 font-['Orbitron'] text-xs tracking-wider py-3.5 rounded-lg bg-[#00e676] text-black font-bold hover:bg-[#00e676]/90 transition-all duration-300 shadow-[0_0_20px_rgba(0,230,118,0.3)] disabled:opacity-50 disabled:cursor-not-allowed"
              >
                {isLoading ? (
                  <>
                    <motion.div animate={{ rotate: 360 }} transition={{ duration: 1, repeat: Infinity, ease: 'linear' }}>
                      <Shield className="h-4 w-4" />
                    </motion.div>
                    <span>AUTHENTICATING...</span>
                  </>
                ) : (
                  <>
                    <Shield className="h-4 w-4" />
                    <span>AUTHORIZE ACCESS</span>
                  </>
                )}
              </button>
            </form>

            <div className="mt-6 pt-5 border-t border-white/5 text-center">
              <p className="font-['Rajdhani'] text-[11px] text-gray-700">
                Only authorized operators can access the command center.
              </p>
            </div>
          </div>
        </div>

        <div className="absolute -top-1 -left-1 w-6 h-6 border-t-2 border-l-2 border-[#00e676]/30 rounded-tl-lg" />
        <div className="absolute -top-1 -right-1 w-6 h-6 border-t-2 border-r-2 border-[#00e676]/30 rounded-tr-lg" />
        <div className="absolute -bottom-1 -left-1 w-6 h-6 border-b-2 border-l-2 border-[#00e676]/30 rounded-bl-lg" />
        <div className="absolute -bottom-1 -right-1 w-6 h-6 border-b-2 border-r-2 border-[#00e676]/30 rounded-br-lg" />
      </motion.div>
    </div>
  );
}
