import { useState, useEffect } from 'react';
import { Link } from 'react-router-dom';
import { motion } from 'framer-motion';
import {
  Mail,
  Phone,
  MapPin,
  Send,
  ExternalLink,
  Globe,
  MessageSquare,
  ArrowRight,
  CheckCircle,
} from 'lucide-react';
import { useAuth } from '../lib/auth';
import { getSiteContent } from '../lib/siteContent';
import OmnitrixSymbol from '../components/OmnitrixSymbol';

export default function Contact() {
  const [, setTick] = useState(0);
  const [formState, setFormState] = useState({
    name: '',
    email: '',
    subject: '',
    message: '',
  });
  const [submitted, setSubmitted] = useState(false);
  const { isAuthenticated, signOut } = useAuth();

  // Re-render when localStorage updates
  useEffect(() => {
    const handler = () => setTick((t) => t + 1);
    window.addEventListener('storage', handler);
    return () => window.removeEventListener('storage', handler);
  }, []);

  const content = getSiteContent();

  const contactMethods = [
    {
      icon: Mail,
      label: 'Email',
      value: content.contactEmail,
      href: content.contactEmailHref,
      color: '#00e676',
      description: 'Drop me an email anytime',
    },
    {
      icon: Phone,
      label: 'Phone',
      value: content.contactPhone,
      href: content.contactPhoneHref,
      color: '#00bcd4',
      description: 'Call or WhatsApp',
    },
    {
      icon: MapPin,
      label: 'Location',
      value: content.contactLocation,
      href: null,
      color: '#ff6d00',
      description: content.contactLocationDescription,
    },
  ];

  const socialLinks = [
    {
      icon: Globe,
      label: 'Behance',
      value: content.behanceUrl.replace('https://', ''),
      href: content.behanceUrl,
      color: '#1769ff',
      description: 'View my design portfolio',
    },
    {
      icon: ExternalLink,
      label: 'LinkedIn',
      value: content.linkedinUrl.replace('https://', ''),
      href: content.linkedinUrl,
      color: '#0077b5',
      description: 'Connect professionally',
    },
  ];

  function handleSubmit(e: React.FormEvent) {
    e.preventDefault();
    setSubmitted(true);
    setTimeout(() => {
      setSubmitted(false);
      setFormState({ name: '', email: '', subject: '', message: '' });
    }, 3000);
  }

  return (
    <div className="min-h-screen bg-[#0a0e1a]">
      {/* Hero */}
      <section className="relative pt-28 pb-16 px-4 overflow-hidden">
        <div className="absolute inset-0 bg-[#0a0e1a]" />
        <div
          className="absolute inset-0"
          style={{
            backgroundImage: `
              radial-gradient(ellipse at 30% 30%, rgba(0,230,118,0.07) 0%, transparent 50%),
              radial-gradient(ellipse at 70% 70%, rgba(0,188,212,0.05) 0%, transparent 50%)
            `,
          }}
        />
        <div
          className="absolute inset-0 opacity-[0.02]"
          style={{
            backgroundImage: `
              linear-gradient(rgba(0,230,118,0.3) 1px, transparent 1px),
              linear-gradient(90deg, rgba(0,230,118,0.3) 1px, transparent 1px)
            `,
            backgroundSize: '60px 60px',
          }}
        />

        <div className="relative z-10 max-w-4xl mx-auto text-center">
          <motion.div
            initial={{ scale: 0, rotate: -90 }}
            animate={{ scale: 1, rotate: 0 }}
            transition={{ type: 'spring', damping: 15, stiffness: 100 }}
            className="flex justify-center mb-6"
          >
            <OmnitrixSymbol size={60} animate={false} />
          </motion.div>

          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.2 }}
            className="font-['Orbitron'] text-[10px] tracking-[0.4em] text-[#00e676]/60 mb-3"
          >
            // ESTABLISH LINK
          </motion.div>

          <motion.h1
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.3 }}
            className="font-['Orbitron'] text-3xl sm:text-5xl font-bold text-white tracking-wider mb-4"
          >
            CONTACT <span className="text-[#00e676]">HQ</span>
          </motion.h1>

          <motion.p
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.4 }}
            className="font-['Rajdhani'] text-gray-400 text-lg max-w-xl mx-auto"
          >
            Got a project in mind? Want to collaborate? Or just want to say hello?
            Reach out through any channel below — I'd love to hear from you.
          </motion.p>
        </div>
      </section>

      {/* Contact Methods + Social */}
      <section className="relative px-4 pb-12">
        <div className="max-w-6xl mx-auto">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <div>
              <div className="font-['Orbitron'] text-[10px] tracking-[0.3em] text-gray-600 mb-4">
                DIRECT CHANNELS
              </div>
              <div className="space-y-4">
                {contactMethods.map((method, i) => {
                  const Icon = method.icon;
                  const Wrapper = method.href ? 'a' : 'div';
                  const wrapperProps = method.href
                    ? {
                        href: method.href,
                        target: method.href.startsWith('http') ? '_blank' as const : undefined,
                        rel: method.href.startsWith('http') ? 'noopener noreferrer' : undefined,
                      }
                    : {};

                  return (
                    <motion.div
                      key={method.label}
                      initial={{ opacity: 0, x: -20 }}
                      animate={{ opacity: 1, x: 0 }}
                      transition={{ delay: 0.2 + i * 0.1 }}
                    >
                      <Wrapper
                        {...wrapperProps}
                        className="group block rounded-xl border border-white/5 bg-gradient-to-br from-[#111827] to-[#0a0e1a] p-5 transition-all duration-300 hover:border-[color:var(--c)]/30 hover:shadow-[0_0_25px_var(--g)]"
                        style={{ '--c': method.color, '--g': method.color + '30' } as React.CSSProperties}
                      >
                        <div className="flex items-start gap-4">
                          <div
                            className="flex-shrink-0 inline-flex items-center justify-center rounded-lg p-2.5 transition-all duration-300 group-hover:scale-110"
                            style={{
                              background: method.color + '15',
                              boxShadow: `0 0 15px ${method.color}30`,
                            }}
                          >
                            <Icon className="h-5 w-5" style={{ color: method.color }} />
                          </div>
                          <div className="min-w-0 flex-1">
                            <div className="font-['Orbitron'] text-xs tracking-widest mb-1" style={{ color: method.color }}>
                              {method.label.toUpperCase()}
                            </div>
                            <div className="font-['Rajdhani'] text-white text-sm truncate">
                              {method.value}
                            </div>
                            <div className="font-['Rajdhani'] text-gray-500 text-xs mt-0.5">
                              {method.description}
                            </div>
                          </div>
                          {method.href && (
                            <ArrowRight className="h-4 w-4 text-gray-700 group-hover:text-gray-400 group-hover:translate-x-1 transition-all flex-shrink-0 mt-2" />
                          )}
                        </div>
                      </Wrapper>
                    </motion.div>
                  );
                })}
              </div>
            </div>

            <div>
              <div className="font-['Orbitron'] text-[10px] tracking-[0.3em] text-gray-600 mb-4">
                PORTFOLIO & SOCIAL
              </div>
              <div className="space-y-4">
                {socialLinks.map((link, i) => {
                  const Icon = link.icon;
                  return (
                    <motion.div
                      key={link.label}
                      initial={{ opacity: 0, x: 20 }}
                      animate={{ opacity: 1, x: 0 }}
                      transition={{ delay: 0.2 + i * 0.1 }}
                    >
                      <a
                        href={link.href}
                        target="_blank"
                        rel="noopener noreferrer"
                        className="group block rounded-xl border border-white/5 bg-gradient-to-br from-[#111827] to-[#0a0e1a] p-5 transition-all duration-300 hover:border-[color:var(--c)]/30 hover:shadow-[0_0_25px_var(--g)]"
                        style={{ '--c': link.color, '--g': link.color + '30' } as React.CSSProperties}
                      >
                        <div className="flex items-start gap-4">
                          <div
                            className="flex-shrink-0 inline-flex items-center justify-center rounded-lg p-2.5 transition-all duration-300 group-hover:scale-110"
                            style={{
                              background: link.color + '15',
                              boxShadow: `0 0 15px ${link.color}30`,
                            }}
                          >
                            <Icon className="h-5 w-5" style={{ color: link.color }} />
                          </div>
                          <div className="min-w-0 flex-1">
                            <div className="font-['Orbitron'] text-xs tracking-widest mb-1" style={{ color: link.color }}>
                              {link.label.toUpperCase()}
                            </div>
                            <div className="font-['Rajdhani'] text-white text-sm truncate">
                              {link.value}
                            </div>
                            <div className="font-['Rajdhani'] text-gray-500 text-xs mt-0.5">
                              {link.description}
                            </div>
                          </div>
                          <ExternalLink className="h-4 w-4 text-gray-700 group-hover:text-gray-400 group-hover:translate-x-0.5 group-hover:-translate-y-0.5 transition-all flex-shrink-0 mt-2" />
                        </div>
                      </a>
                    </motion.div>
                  );
                })}

                <motion.div
                  initial={{ opacity: 0, y: 20 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ delay: 0.5 }}
                  className="rounded-xl border border-[#00e676]/15 bg-gradient-to-br from-[#111827] to-[#0a0e1a] p-5"
                >
                  <div className="flex items-center gap-3">
                    <div className="relative">
                      <div className="h-3 w-3 rounded-full bg-[#00e676]" />
                      <div className="absolute inset-0 h-3 w-3 rounded-full bg-[#00e676] animate-ping opacity-40" />
                    </div>
                    <div>
                      <div className="font-['Orbitron'] text-xs tracking-wider text-[#00e676]">
                        AVAILABLE FOR WORK
                      </div>
                      <div className="font-['Rajdhani'] text-gray-500 text-xs">
                        Open to freelance, full-time & collaboration opportunities
                      </div>
                    </div>
                  </div>
                </motion.div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Contact Form */}
      <section className="relative px-4 pb-24">
        <div className="max-w-3xl mx-auto">
          <motion.div
            initial={{ opacity: 0, y: 30 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.5 }}
            className="rounded-2xl border border-[#00e676]/10 bg-gradient-to-br from-[#111827] to-[#0a0e1a] overflow-hidden"
          >
            <div className="h-1 w-full" style={{ background: 'linear-gradient(90deg, transparent, #00e676, transparent)' }} />

            <div className="p-6 sm:p-10">
              <div className="flex items-center gap-3 mb-6">
                <MessageSquare className="h-5 w-5 text-[#00e676]" />
                <h2 className="font-['Orbitron'] text-lg font-bold text-white tracking-wider">
                  SEND A <span className="text-[#00e676]">TRANSMISSION</span>
                </h2>
              </div>

              {submitted ? (
                <motion.div
                  initial={{ scale: 0.9, opacity: 0 }}
                  animate={{ scale: 1, opacity: 1 }}
                  className="text-center py-12"
                >
                  <CheckCircle className="h-12 w-12 text-[#00e676] mx-auto mb-4" />
                  <div className="font-['Orbitron'] text-sm tracking-wider text-[#00e676] mb-2">
                    TRANSMISSION SENT
                  </div>
                  <p className="font-['Rajdhani'] text-gray-400 text-sm">
                    Message received! I'll get back to you soon.
                  </p>
                </motion.div>
              ) : (
                <form onSubmit={handleSubmit} className="space-y-5">
                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-5">
                    <div>
                      <label className="block font-['Orbitron'] text-[10px] tracking-widest text-gray-500 mb-2">YOUR NAME</label>
                      <input
                        type="text"
                        required
                        value={formState.name}
                        onChange={(e) => setFormState((s) => ({ ...s, name: e.target.value }))}
                        className="w-full bg-black/40 border border-white/10 rounded-lg px-4 py-3 text-white font-['Rajdhani'] text-sm focus:outline-none focus:border-[#00e676]/50 focus:shadow-[0_0_15px_rgba(0,230,118,0.1)] transition-all placeholder-gray-700"
                        placeholder="Your name"
                      />
                    </div>
                    <div>
                      <label className="block font-['Orbitron'] text-[10px] tracking-widest text-gray-500 mb-2">YOUR EMAIL</label>
                      <input
                        type="email"
                        required
                        value={formState.email}
                        onChange={(e) => setFormState((s) => ({ ...s, email: e.target.value }))}
                        className="w-full bg-black/40 border border-white/10 rounded-lg px-4 py-3 text-white font-['Rajdhani'] text-sm focus:outline-none focus:border-[#00e676]/50 focus:shadow-[0_0_15px_rgba(0,230,118,0.1)] transition-all placeholder-gray-700"
                        placeholder="you@email.com"
                      />
                    </div>
                  </div>
                  <div>
                    <label className="block font-['Orbitron'] text-[10px] tracking-widest text-gray-500 mb-2">SUBJECT</label>
                    <input
                      type="text"
                      required
                      value={formState.subject}
                      onChange={(e) => setFormState((s) => ({ ...s, subject: e.target.value }))}
                      className="w-full bg-black/40 border border-white/10 rounded-lg px-4 py-3 text-white font-['Rajdhani'] text-sm focus:outline-none focus:border-[#00e676]/50 focus:shadow-[0_0_15px_rgba(0,230,118,0.1)] transition-all placeholder-gray-700"
                      placeholder="Project inquiry, collaboration, etc."
                    />
                  </div>
                  <div>
                    <label className="block font-['Orbitron'] text-[10px] tracking-widest text-gray-500 mb-2">MESSAGE</label>
                    <textarea
                      required
                      rows={5}
                      value={formState.message}
                      onChange={(e) => setFormState((s) => ({ ...s, message: e.target.value }))}
                      className="w-full bg-black/40 border border-white/10 rounded-lg px-4 py-3 text-white font-['Rajdhani'] text-sm focus:outline-none focus:border-[#00e676]/50 focus:shadow-[0_0_15px_rgba(0,230,118,0.1)] transition-all resize-y placeholder-gray-700"
                      placeholder="Tell me about your project or idea..."
                    />
                  </div>
                  <button
                    type="submit"
                    className="flex items-center justify-center gap-2 font-['Orbitron'] text-xs tracking-wider px-8 py-3.5 rounded-lg bg-[#00e676] text-black font-bold hover:bg-[#00e676]/90 transition-all duration-300 shadow-[0_0_20px_rgba(0,230,118,0.3)]"
                  >
                    <Send className="h-4 w-4" />
                    SEND TRANSMISSION
                  </button>
                </form>
              )}
            </div>
          </motion.div>
        </div>
      </section>

      {/* Footer */}
      <footer className="relative py-10 px-4 border-t border-[#00e676]/10">
        <div className="absolute inset-0 bg-[#0a0e1a]" />
        <div className="relative z-10 max-w-7xl mx-auto">
          <div className="flex flex-col md:flex-row items-center justify-between gap-6">
            <div className="text-center md:text-left">
              <div className="font-['Orbitron'] text-sm font-bold text-white tracking-wider mb-1">
                KALYAN<span className="text-[#00e676]">.DEV</span>
              </div>
              <div className="font-['Rajdhani'] text-xs text-gray-600">
                {content.footerQuote}
              </div>
            </div>
            <div className="flex items-center gap-4 text-[11px]">
              <a href={content.behanceUrl} target="_blank" rel="noopener noreferrer" className="font-['Rajdhani'] text-gray-600 hover:text-[#1769ff] transition-colors">Behance</a>
              <span className="text-gray-800">·</span>
              <a href={content.linkedinUrl} target="_blank" rel="noopener noreferrer" className="font-['Rajdhani'] text-gray-600 hover:text-[#0077b5] transition-colors">LinkedIn</a>
              <span className="text-gray-800">·</span>
              {isAuthenticated ? (
                <Link to="/" onClick={() => signOut()} className="font-['Rajdhani'] text-gray-700 hover:text-gray-400 transition-colors">Sign out</Link>
              ) : (
                <Link to="/signin" className="font-['Rajdhani'] text-gray-700 hover:text-gray-400 transition-colors">Sign in</Link>
              )}
            </div>
            <div className="text-center md:text-right">
              <div className="font-['Orbitron'] text-[10px] tracking-wider text-gray-600">
                © {new Date().getFullYear()} KONDAVETI KALYAN SAI
              </div>
            </div>
          </div>
        </div>
      </footer>
    </div>
  );
}
