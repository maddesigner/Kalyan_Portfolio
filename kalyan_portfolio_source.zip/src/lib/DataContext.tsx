/**
 * DataContext.tsx
 * Loads all data from Firestore ONCE on app start,
 * then provides it synchronously to every component via React Context.
 *
 * This means Home.tsx, Contact.tsx, CategoryPage.tsx etc. can keep
 * calling getSiteContent() / getProjects() and get real data instantly.
 */

import { createContext, useContext, useState, useEffect, ReactNode } from 'react';
import { Project } from '../types';
import { SiteContent, defaultContent } from './siteContent';
import {
  getProjectsFromCloud,
  getSiteContentFromCloud,
  addProjectToCloud,
  updateProjectInCloud,
  deleteProjectFromCloud,
  resetProjectsToDefaults,
  updateSiteContentInCloud,
  resetSiteContentInCloud,
} from './cloudStore';

// ─── Context shape ────────────────────────────────────────────────────────────

interface DataContextType {
  projects: Project[];
  siteContent: SiteContent;
  loading: boolean;
  // project mutations
  addProject: (p: Omit<Project, 'id'>) => Promise<Project>;
  updateProject: (id: string, updates: Partial<Project>) => Promise<void>;
  deleteProject: (id: string) => Promise<void>;
  resetProjects: () => Promise<void>;
  reloadProjects: () => Promise<void>;
  // content mutations
  updateContent: (updates: Partial<SiteContent>) => Promise<SiteContent>;
  resetContent: () => Promise<void>;
}

const DataContext = createContext<DataContextType>({
  projects: [],
  siteContent: defaultContent,
  loading: true,
  addProject: async () => ({ id: '', category: 'civil', title: '', description: '', imageUrl: '', tags: [], date: '', client: '', tools: [], details: '', link: '' }),
  updateProject: async () => {},
  deleteProject: async () => {},
  resetProjects: async () => {},
  reloadProjects: async () => {},
  updateContent: async () => defaultContent,
  resetContent: async () => {},
});

// ─── Provider ─────────────────────────────────────────────────────────────────

export function DataProvider({ children }: { children: ReactNode }) {
  const [projects, setProjects] = useState<Project[]>([]);
  const [siteContent, setSiteContent] = useState<SiteContent>(defaultContent);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    async function loadAll() {
      try {
        const [p, c] = await Promise.all([
          getProjectsFromCloud(),
          getSiteContentFromCloud(),
        ]);
        setProjects(p);
        setSiteContent(c);
      } catch (err) {
        console.error('DataContext: failed to load from Firestore', err);
      } finally {
        setLoading(false);
      }
    }
    loadAll();
  }, []);

  async function reloadProjects() {
    const p = await getProjectsFromCloud();
    setProjects(p);
  }

  async function addProject(proj: Omit<Project, 'id'>): Promise<Project> {
    const newP = await addProjectToCloud(proj);
    await reloadProjects();
    return newP;
  }

  async function updateProject(id: string, updates: Partial<Project>) {
    await updateProjectInCloud(id, updates);
    await reloadProjects();
  }

  async function deleteProject(id: string) {
    await deleteProjectFromCloud(id);
    await reloadProjects();
  }

  async function resetProjects() {
    await resetProjectsToDefaults();
    await reloadProjects();
  }

  async function updateContent(updates: Partial<SiteContent>): Promise<SiteContent> {
    const updated = await updateSiteContentInCloud(updates);
    setSiteContent(updated);
    return updated;
  }

  async function resetContent() {
    await resetSiteContentInCloud();
    setSiteContent(defaultContent);
  }

  return (
    <DataContext.Provider
      value={{
        projects,
        siteContent,
        loading,
        addProject,
        updateProject,
        deleteProject,
        resetProjects,
        reloadProjects,
        updateContent,
        resetContent,
      }}
    >
      {children}
    </DataContext.Provider>
  );
}

// ─── Hook ─────────────────────────────────────────────────────────────────────

export function useData() {
  return useContext(DataContext);
}

// ─── Backward-compatible synchronous-style accessors ─────────────────────────
// These are called at the top level of Home.tsx / Contact.tsx / CategoryPage.tsx
// They read from the context cache, which is already loaded by the time any
// component renders (DataProvider shows a loader until Firestore responds).

let _projects: Project[] = [];
let _siteContent: SiteContent = defaultContent;

export function setGlobalCache(projects: Project[], siteContent: SiteContent) {
  _projects = projects;
  _siteContent = siteContent;
}

export function getProjectsSync(): Project[] { return _projects; }
export function getSiteContentSync(): SiteContent { return _siteContent; }
export function getProjectsByCategorySync(category: string): Project[] {
  return _projects.filter((p) => p.category === category);
}
