import { createContext, useContext, useState, useEffect, ReactNode } from 'react';

interface AuthContextType {
  isAuthenticated: boolean;
  signIn: (username: string, password: string) => boolean;
  signOut: () => void;
  changePassword: (currentPassword: string, newPassword: string) => boolean;
  changeUsername: (currentPassword: string, newUsername: string) => boolean;
  getCredentials: () => { username: string; password: string };
}

const AuthContext = createContext<AuthContextType>({
  isAuthenticated: false,
  signIn: () => false,
  signOut: () => {},
  changePassword: () => false,
  changeUsername: () => false,
  getCredentials: () => ({ username: '', password: '' }),
});

const AUTH_KEY = 'kalyan_portfolio_auth';
const CREDS_KEY = 'kalyan_portfolio_creds';

const DEFAULT_USERNAME = 'kalyan';
const DEFAULT_PASSWORD = 'omnitrix2024';

function getStoredCredentials(): { username: string; password: string } {
  const stored = localStorage.getItem(CREDS_KEY);
  if (stored) {
    try {
      return JSON.parse(stored);
    } catch {
      return { username: DEFAULT_USERNAME, password: DEFAULT_PASSWORD };
    }
  }
  const defaults = { username: DEFAULT_USERNAME, password: DEFAULT_PASSWORD };
  localStorage.setItem(CREDS_KEY, JSON.stringify(defaults));
  return defaults;
}

export function AuthProvider({ children }: { children: ReactNode }) {
  const [isAuthenticated, setIsAuthenticated] = useState(() => {
    return localStorage.getItem(AUTH_KEY) === 'true';
  });

  useEffect(() => {
    if (isAuthenticated) {
      localStorage.setItem(AUTH_KEY, 'true');
    } else {
      localStorage.removeItem(AUTH_KEY);
    }
  }, [isAuthenticated]);

  function signIn(username: string, password: string): boolean {
    const creds = getStoredCredentials();
    if (username === creds.username && password === creds.password) {
      setIsAuthenticated(true);
      return true;
    }
    return false;
  }

  function signOut() {
    setIsAuthenticated(false);
  }

  function changePassword(currentPassword: string, newPassword: string): boolean {
    const creds = getStoredCredentials();
    if (currentPassword !== creds.password) return false;
    if (!newPassword.trim() || newPassword.length < 4) return false;
    const updated = { username: creds.username, password: newPassword };
    localStorage.setItem(CREDS_KEY, JSON.stringify(updated));
    return true;
  }

  function changeUsername(currentPassword: string, newUsername: string): boolean {
    const creds = getStoredCredentials();
    if (currentPassword !== creds.password) return false;
    if (!newUsername.trim() || newUsername.length < 2) return false;
    const updated = { username: newUsername, password: creds.password };
    localStorage.setItem(CREDS_KEY, JSON.stringify(updated));
    return true;
  }

  function getCredentials(): { username: string; password: string } {
    return getStoredCredentials();
  }

  return (
    <AuthContext.Provider
      value={{ isAuthenticated, signIn, signOut, changePassword, changeUsername, getCredentials }}
    >
      {children}
    </AuthContext.Provider>
  );
}

export function useAuth() {
  return useContext(AuthContext);
}
