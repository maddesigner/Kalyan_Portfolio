/**
 * store.ts
 * Public API for project data.
 * Synchronous getters read from in-memory cache (loaded from Firestore at app start).
 * Mutations go through DataContext (used by Dashboard.tsx).
 */

import { getProjectsSync, getProjectsByCategorySync } from './DataContext';
import { Project } from '../types';

export function getProjects(): Project[] {
  return getProjectsSync();
}

export function getProjectsByCategory(category: string): Project[] {
  return getProjectsByCategorySync(category);
}

export function getProjectById(id: string): Project | undefined {
  return getProjectsSync().find((p) => p.id === id);
}

// These are async — used directly in Dashboard via useData() hook
// Re-exported here for any legacy imports
export {
  addProjectToCloud as addProject,
  updateProjectInCloud as updateProject,
  deleteProjectFromCloud as deleteProject,
  resetProjectsToDefaults as resetToDefaults,
} from './cloudStore';
