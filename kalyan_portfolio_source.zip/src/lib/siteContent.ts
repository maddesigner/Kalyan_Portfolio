/**
 * siteContent.ts
 * Public API for site content data.
 * getSiteContent() reads from in-memory cache (loaded from Firestore at app start).
 */

export interface SiteContent {
  heroSubtitle: string;
  heroTitleLine1: string;
  heroTitleLine2: string;
  heroTagline: string;
  scrollIndicator: string;
  categoriesTag: string;
  categoriesTitle: string;
  categoriesDescription: string;
  aboutTitle: string;
  aboutParagraph1: string;
  aboutParagraph2: string;
  footerQuote: string;
  contactEmail: string;
  contactEmailHref: string;
  contactPhone: string;
  contactPhoneHref: string;
  contactLocation: string;
  contactLocationDescription: string;
  behanceUrl: string;
  linkedinUrl: string;
}

export const defaultContent: SiteContent = {
  heroSubtitle: 'PRODUCT DESIGNER',
  heroTitleLine1: 'KONDAVETI',
  heroTitleLine2: 'KALYAN SAI',
  heroTagline:
    'Product Designer — Crafting experiences across dimensions. From civil blueprints to digital interfaces, every project is an alien transformation.',
  scrollIndicator: 'SELECT YOUR ALIEN',
  categoriesTag: '// TRANSFORM',
  categoriesTitle: 'CHOOSE YOUR DIMENSION',
  categoriesDescription:
    'Each discipline is like a different alien form — unique powers, unique perspectives. Select a category to explore the projects within.',
  aboutTitle: 'ABOUT THE OPERATOR',
  aboutParagraph1:
    "I'm Kondaveti Kalyan Sai — a multi-disciplinary product designer who believes that creativity knows no boundaries. Just like the Omnitrix can transform into any alien, I can adapt to any design challenge — whether it's drafting civil engineering plans, modeling mechanical assemblies in SolidWorks, crafting brand identities, designing intuitive UIs, or editing cinematic videos.",
  aboutParagraph2:
    'With a background spanning civil engineering, mechanical design, graphic design, UI/UX, and video editing, I bring a unique cross-disciplinary perspective to every project. Each field informs the other — structural thinking from civil, precision from mechanical, visual storytelling from graphic design, user empathy from UI work, and timing from video editing.',
  footerQuote: 'It started when an alien device did what it did...',
  contactEmail: 'kalyansai266066@gmail.com',
  contactEmailHref: 'mailto:kalyansai266066@gmail.com',
  contactPhone: '+91 95029 75332',
  contactPhoneHref: 'tel:+919502975332',
  contactLocation: 'India',
  contactLocationDescription: 'Available for remote & on-site work',
  behanceUrl: 'https://www.behance.net/kondavetikalyansai',
  linkedinUrl: 'https://linkedin.com/in/kondaveti-kalyan-921791209',
};

import { getSiteContentSync } from './DataContext';
export { updateSiteContentInCloud as updateSiteContent, resetSiteContentInCloud as resetSiteContent } from './cloudStore';

export function getSiteContent(): SiteContent {
  return getSiteContentSync();
}
