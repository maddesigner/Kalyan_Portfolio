import { initializeApp } from 'firebase/app';
import { getFirestore } from 'firebase/firestore';

// ⚠️ REPLACE THESE VALUES with your actual Firebase config keys!
// You get these from: Firebase Console → Your Project → Project Settings → Your Apps → SDK setup
const firebaseConfig = {
  apiKey: "PASTE_YOUR_apiKey_HERE",
  authDomain: "PASTE_YOUR_authDomain_HERE",
  projectId: "PASTE_YOUR_projectId_HERE",
  storageBucket: "PASTE_YOUR_storageBucket_HERE",
  messagingSenderId: "PASTE_YOUR_messagingSenderId_HERE",
  appId: "PASTE_YOUR_appId_HERE",
};

const app = initializeApp(firebaseConfig);
export const db = getFirestore(app);
