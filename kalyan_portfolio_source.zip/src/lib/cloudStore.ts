/**
 * cloudStore.ts
 * Replaces localStorage with Firebase Firestore.
 * All your portfolio data is saved to the cloud here.
 */

import {
  doc,
  getDoc,
  setDoc,
  updateDoc,
  arrayUnion,
  arrayRemove,
} from 'firebase/firestore';
import { db } from './firebase';
import { Project } from '../types';
import { SiteContent, defaultContent } from './siteContent';
import { defaultProjects } from './data';

// ─── Document references ─────────────────────────────────────────────────────
// Everything lives under "portfolio/main" in Firestore
const MAIN_DOC = doc(db, 'portfolio', 'main');

// ─── Helpers ─────────────────────────────────────────────────────────────────

async function ensureDocExists() {
  const snap = await getDoc(MAIN_DOC);
  if (!snap.exists()) {
    // First time setup: seed Firestore with defaults
    await setDoc(MAIN_DOC, {
      projects: defaultProjects,
      siteContent: defaultContent,
    });
  }
}

// ─── Projects ─────────────────────────────────────────────────────────────────

export async function getProjectsFromCloud(): Promise<Project[]> {
  await ensureDocExists();
  const snap = await getDoc(MAIN_DOC);
  return snap.data()?.projects ?? defaultProjects;
}

export async function addProjectToCloud(project: Omit<Project, 'id'>): Promise<Project> {
  await ensureDocExists();
  const newProject: Project = {
    ...project,
    id: `${project.category}-${Date.now()}`,
  };
  await updateDoc(MAIN_DOC, {
    projects: arrayUnion(newProject),
  });
  return newProject;
}

export async function updateProjectInCloud(id: string, updates: Partial<Project>): Promise<void> {
  const projects = await getProjectsFromCloud();
  const updated = projects.map((p) => (p.id === id ? { ...p, ...updates } : p));
  await updateDoc(MAIN_DOC, { projects: updated });
}

export async function deleteProjectFromCloud(id: string): Promise<void> {
  const projects = await getProjectsFromCloud();
  const target = projects.find((p) => p.id === id);
  if (target) {
    await updateDoc(MAIN_DOC, { projects: arrayRemove(target) });
  }
}

export async function resetProjectsToDefaults(): Promise<void> {
  await updateDoc(MAIN_DOC, { projects: defaultProjects });
}

// ─── Site Content ──────────────────────────────────────────────────────────────

export async function getSiteContentFromCloud(): Promise<SiteContent> {
  await ensureDocExists();
  const snap = await getDoc(MAIN_DOC);
  const stored = snap.data()?.siteContent;
  return stored ? { ...defaultContent, ...stored } : defaultContent;
}

export async function updateSiteContentInCloud(updates: Partial<SiteContent>): Promise<SiteContent> {
  const current = await getSiteContentFromCloud();
  const updated = { ...current, ...updates };
  await updateDoc(MAIN_DOC, { siteContent: updated });
  return updated;
}

export async function resetSiteContentInCloud(): Promise<void> {
  await updateDoc(MAIN_DOC, { siteContent: defaultContent });
}
