import { motion } from 'framer-motion';

export default function OmnitrixSymbol({ size = 120, animate = true }: { size?: number; animate?: boolean }) {
  const Wrapper = animate ? motion.div : 'div';
  const animProps = animate
    ? {
        animate: { rotate: 360 },
        transition: { duration: 60, repeat: Infinity, ease: 'linear' as const },
      }
    : {};

  return (
    <Wrapper
      className="relative inline-flex items-center justify-center"
      style={{ width: size, height: size }}
      {...animProps}
    >
      <svg
        viewBox="0 0 200 200"
        width={size}
        height={size}
        fill="none"
        xmlns="http://www.w3.org/2000/svg"
      >
        <circle cx="100" cy="100" r="95" stroke="#00e676" strokeWidth="4" opacity="0.3" />
        <circle cx="100" cy="100" r="85" stroke="#00e676" strokeWidth="6" opacity="0.6" />
        <path
          d="M60 60 L100 100 L140 60"
          stroke="#00e676"
          strokeWidth="8"
          strokeLinecap="round"
          strokeLinejoin="round"
          fill="none"
        />
        <path
          d="M60 140 L100 100 L140 140"
          stroke="#00e676"
          strokeWidth="8"
          strokeLinecap="round"
          strokeLinejoin="round"
          fill="none"
        />
        <circle cx="100" cy="100" r="6" fill="#00e676" />
        <line x1="40" y1="40" x2="55" y2="55" stroke="#00e676" strokeWidth="3" strokeLinecap="round" />
        <line x1="160" y1="40" x2="145" y2="55" stroke="#00e676" strokeWidth="3" strokeLinecap="round" />
        <line x1="40" y1="160" x2="55" y2="145" stroke="#00e676" strokeWidth="3" strokeLinecap="round" />
        <line x1="160" y1="160" x2="145" y2="145" stroke="#00e676" strokeWidth="3" strokeLinecap="round" />
      </svg>
      {animate && (
        <motion.div
          className="absolute inset-0 rounded-full"
          style={{
            background: 'radial-gradient(circle, rgba(0,230,118,0.15) 0%, transparent 70%)',
          }}
          animate={{ scale: [1, 1.2, 1], opacity: [0.5, 0.8, 0.5] }}
          transition={{ duration: 3, repeat: Infinity, ease: 'easeInOut' }}
        />
      )}
    </Wrapper>
  );
}
