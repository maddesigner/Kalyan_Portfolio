import { motion, AnimatePresence } from 'framer-motion';
import { X, ExternalLink, Calendar, User, Wrench, Box } from 'lucide-react';
import { Project } from '../types';
import { categories } from '../lib/data';

interface Props {
  project: Project | null;
  onClose: () => void;
}

function isSketchfabUrl(url: string): boolean {
  return url.includes('sketchfab.com/3d-models') || url.includes('sketchfab.com/models');
}

function extractSketchfabId(url: string): string | null {
  // Match patterns like:
  // https://sketchfab.com/3d-models/model-name-abc123def456
  // https://sketchfab.com/models/abc123def456
  const match3d = url.match(/sketchfab\.com\/3d-models\/[a-zA-Z0-9-]+-([a-f0-9]{20,})/);
  if (match3d) return match3d[1];
  const matchModels = url.match(/sketchfab\.com\/models\/([a-f0-9]{20,})/);
  if (matchModels) return matchModels[1];
  return null;
}

function isVideoUrl(url: string): boolean {
  const lower = url.toLowerCase();
  if (lower.includes('youtube.com/watch') || lower.includes('youtu.be/')) return true;
  if (lower.includes('vimeo.com/')) return true;
  return false;
}

function getYouTubeEmbedUrl(url: string): string | null {
  const match = url.match(/(?:youtube\.com\/watch\?v=|youtu\.be\/)([a-zA-Z0-9_-]+)/);
  if (match) return `https://www.youtube.com/embed/${match[1]}`;
  return null;
}

function getVimeoEmbedUrl(url: string): string | null {
  const match = url.match(/vimeo\.com\/(\d+)/);
  if (match) return `https://player.vimeo.com/video/${match[1]}`;
  return null;
}

export default function ProjectModal({ project, onClose }: Props) {
  if (!project) return null;

  const category = categories.find((c) => c.slug === project.category);
  const color = category?.color || '#00e676';
  const glow = category?.glowColor || 'rgba(0,230,118,0.4)';

  // Determine the primary media type from the link
  const link = project.link || '';
  const sketchfabId = project.sketchfabId || (link && isSketchfabUrl(link) ? extractSketchfabId(link) : null);
  const isVideo = link && isVideoUrl(link);
  const isSketchfab = !!sketchfabId;
  const isGlbModel = !!(project.modelUrl && (project.modelUrl.endsWith('.glb') || project.modelUrl.endsWith('.gltf')));

  // Determine what to show in the media area (priority: GLB > Sketchfab > Video > Image)
  const showGlbModel = isGlbModel;
  const showSketchfab = isSketchfab && !showGlbModel;
  const showVideo = isVideo && !showSketchfab && !showGlbModel;
  const showImage = !showSketchfab && !showVideo && !showGlbModel;

  return (
    <AnimatePresence>
      <motion.div
        key={project.id}
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        exit={{ opacity: 0 }}
        className="fixed inset-0 z-[100] flex items-center justify-center p-4"
        onClick={onClose}
      >
        <div className="absolute inset-0 bg-black/80 backdrop-blur-sm" />

        <motion.div
          initial={{ scale: 0.9, opacity: 0, y: 20 }}
          animate={{ scale: 1, opacity: 1, y: 0 }}
          exit={{ scale: 0.9, opacity: 0, y: 20 }}
          transition={{ type: 'spring', damping: 25, stiffness: 300 }}
          className="relative w-full max-w-4xl max-h-[92vh] overflow-y-auto rounded-2xl border bg-gradient-to-br from-[#111827] to-[#0a0e1a]"
          style={{ borderColor: `${color}30` }}
          onClick={(e: React.MouseEvent) => e.stopPropagation()}
        >
          {/* Top glow line */}
          <div className="h-1 w-full" style={{ background: `linear-gradient(90deg, transparent, ${color}, transparent)` }} />

          {/* Close button */}
          <button onClick={onClose} className="absolute top-4 right-4 z-10 rounded-lg p-2 text-gray-400 hover:text-white transition-colors bg-black/40 backdrop-blur-sm border border-white/10">
            <X className="h-5 w-5" />
          </button>

          {/* ===== GLB/GLTF 3D MODEL VIEWER ===== */}
          {showGlbModel && project.modelUrl && (
            <div className="w-full">
              <div className="flex items-center gap-2 px-6 pt-5 pb-3">
                <Box className="h-5 w-5" style={{ color }} />
                <span className="font-['Orbitron'] text-[10px] tracking-widest" style={{ color }}>3D MODEL</span>
                <span className="font-['Rajdhani'] text-[10px] text-gray-600 ml-2">Drag to rotate · Scroll to zoom · Double-click to focus</span>
              </div>
              <div className="w-full bg-black/80" style={{ height: '65vh' }}>
                {/* @ts-expect-error model-viewer is a custom web component */}
                <model-viewer
                  src={project.modelUrl}
                  alt={project.title}
                  ar
                  ar-modes="webxr scene-viewer quick-look"
                  camera-controls
                  touch-action="pan-y"
                  enable-pan
                  auto-rotate
                  rotation-per-second="30deg"
                  interaction-prompt="auto"
                  shadow-intensity="1"
                  exposure="1"
                  style={{ width: '100%', height: '100%', backgroundColor: 'transparent' }}
                />
              </div>
            </div>
          )}

          {/* ===== SKETCHFAB 3D MODEL EMBED ===== */}
          {showSketchfab && sketchfabId && (
            <div className="w-full">
              <div className="flex items-center gap-2 px-6 pt-5 pb-3">
                <Box className="h-5 w-5" style={{ color }} />
                <span className="font-['Orbitron'] text-[10px] tracking-widest" style={{ color }}>SKETCHFAB 3D MODEL</span>
                <span className="font-['Rajdhani'] text-[10px] text-gray-600 ml-2">Drag to rotate · Scroll to zoom</span>
              </div>
              <div className="w-full bg-black/60" style={{ height: '65vh' }}>
                <iframe
                  src={`https://sketchfab.com/models/${sketchfabId}/embed?autostart=1&ui_theme=dark&ui_infos=0&ui_controls=1&ui_stop=0&ui_inspector=0&ui_watermark=0&ui_watermark_link=0&ui_help=0&ui_settings=0&ui_vr=0&ui_fullscreen=1&ui_annotations=0`}
                  className="w-full h-full border-0"
                  title={project.title}
                  allow="autoplay; fullscreen; xr-spatial-tracking"
                  allowFullScreen
                />
              </div>
            </div>
          )}

          {/* ===== VIDEO PLAYER ===== */}
          {showVideo && (
            <div className="w-full">
              <div className="flex items-center gap-2 px-6 pt-5 pb-3">
                <Box className="h-5 w-5" style={{ color }} />
                <span className="font-['Orbitron'] text-[10px] tracking-widest" style={{ color }}>VIDEO</span>
              </div>
              <div className="w-full bg-black" style={{ minHeight: '300px' }}>
                {getYouTubeEmbedUrl(link) && (
                  <iframe src={getYouTubeEmbedUrl(link)!} className="w-full border-0" style={{ height: '56vh' }} title={project.title} allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture" allowFullScreen />
                )}
                {!getYouTubeEmbedUrl(link) && getVimeoEmbedUrl(link) && (
                  <iframe src={getVimeoEmbedUrl(link)!} className="w-full border-0" style={{ height: '56vh' }} title={project.title} allow="autoplay; fullscreen; picture-in-picture" allowFullScreen />
                )}
                {!getYouTubeEmbedUrl(link) && !getVimeoEmbedUrl(link) && (
                  <video src={link} controls className="w-full" style={{ maxHeight: '60vh' }} preload="metadata">Your browser does not support the video tag.</video>
                )}
              </div>
            </div>
          )}

          {/* ===== IMAGE AREA ===== */}
          {showImage && (
            <div
              className="relative h-64 sm:h-80"
              style={{ background: `linear-gradient(135deg, ${color}15, ${color}05)` }}
            >
              {project.imageUrl ? (
                <img src={project.imageUrl} alt={project.title} className="h-full w-full object-cover" />
              ) : (
                <div className="flex h-full items-center justify-center">
                  <div className="font-['Orbitron'] text-7xl font-bold opacity-10" style={{ color }}>{project.title.charAt(0)}</div>
                </div>
              )}

              <div className="absolute inset-0 pointer-events-none opacity-20" style={{ backgroundImage: `repeating-linear-gradient(0deg, transparent, transparent 2px, ${color}08 2px, ${color}08 3px)` }} />
              <div className="absolute bottom-4 left-4 font-['Orbitron'] text-[10px] tracking-widest px-3 py-1 rounded-full border backdrop-blur-sm bg-black/50" style={{ color, borderColor: `${color}40` }}>
                {category?.title.toUpperCase()}
              </div>
            </div>
          )}

          {/* Content */}
          <div className="p-6 sm:p-8">
            <h2 className="font-['Orbitron'] text-xl sm:text-2xl font-bold tracking-wider mb-4" style={{ color }}>
              {project.title.toUpperCase()}
            </h2>

            <div className="flex flex-wrap gap-4 mb-6 text-xs font-['Rajdhani'] text-gray-400">
              {project.date && (
                <div className="flex items-center gap-1.5">
                  <Calendar className="h-3.5 w-3.5" style={{ color }} />
                  <span>{new Date(project.date).toLocaleDateString('en-US', { year: 'numeric', month: 'long', day: 'numeric' })}</span>
                </div>
              )}
              {project.client && (
                <div className="flex items-center gap-1.5">
                  <User className="h-3.5 w-3.5" style={{ color }} />
                  <span>{project.client}</span>
                </div>
              )}
              {project.tools.length > 0 && (
                <div className="flex items-center gap-1.5">
                  <Wrench className="h-3.5 w-3.5" style={{ color }} />
                  <span>{project.tools.join(', ')}</span>
                </div>
              )}
              {(showSketchfab || showGlbModel) && (
                <div className="flex items-center gap-1.5">
                  <Box className="h-3.5 w-3.5" style={{ color }} />
                  <span>Interactive 3D Model</span>
                </div>
              )}
            </div>

            <p className="text-gray-300 font-['Rajdhani'] text-base leading-relaxed mb-6">{project.description}</p>

            <div className="mb-6">
              <h3 className="font-['Orbitron'] text-xs tracking-widest mb-3" style={{ color }}>PROJECT DETAILS</h3>
              <p className="text-gray-400 font-['Rajdhani'] text-sm leading-relaxed whitespace-pre-line">{project.details}</p>
            </div>

            <div className="flex flex-wrap gap-2 mb-6">
              {project.tags.map((tag) => (
                <span key={tag} className="font-['Orbitron'] text-[10px] tracking-wider px-3 py-1 rounded-full border" style={{ color: `${color}cc`, borderColor: `${color}30`, background: `${color}08` }}>
                  {tag.toUpperCase()}
                </span>
              ))}
            </div>

            <div className="mb-6">
              <h3 className="font-['Orbitron'] text-xs tracking-widest mb-3" style={{ color }}>TOOLS & TECHNOLOGIES</h3>
              <div className="flex flex-wrap gap-2">
                {project.tools.map((tool) => (
                  <span key={tool} className="font-['Rajdhani'] text-sm px-3 py-1 rounded-lg bg-white/5 border border-white/10 text-gray-300">{tool}</span>
                ))}
              </div>
            </div>

            {/* External link — only show for non-Sketchfab, non-video links */}
            {project.link && !showSketchfab && !showVideo && (
              <a href={project.link} target="_blank" rel="noopener noreferrer" className="inline-flex items-center gap-2 font-['Orbitron'] text-xs tracking-wider px-5 py-2.5 rounded-lg border transition-all duration-300 hover:shadow-[0_0_20px_var(--glow)]" style={{ color, borderColor: `${color}40`, background: `${color}10`, '--glow': glow } as React.CSSProperties}>
                <ExternalLink className="h-4 w-4" />VIEW PROJECT
              </a>
            )}

            {/* Open in Sketchfab link */}
            {showSketchfab && (
              <a href={link && isSketchfabUrl(link) ? link : `https://sketchfab.com/models/${sketchfabId}`} target="_blank" rel="noopener noreferrer" className="inline-flex items-center gap-2 font-['Orbitron'] text-xs tracking-wider px-5 py-2.5 rounded-lg border transition-all duration-300 hover:shadow-[0_0_20px_var(--glow)]" style={{ color, borderColor: `${color}40`, background: `${color}10`, '--glow': glow } as React.CSSProperties}>
                <ExternalLink className="h-4 w-4" />OPEN IN SKETCHFAB
              </a>
            )}
          </div>
        </motion.div>
      </motion.div>
    </AnimatePresence>
  );
}
