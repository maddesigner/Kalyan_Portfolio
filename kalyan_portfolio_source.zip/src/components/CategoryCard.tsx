import { Link } from 'react-router-dom';
import { motion } from 'framer-motion';
import {
  Building2,
  Cog,
  Palette,
  MonitorSmartphone,
  Film,
  Box,
} from 'lucide-react';
import { Category } from '../types';

const iconMap: Record<string, React.ElementType> = {
  'building-2': Building2,
  cog: Cog,
  palette: Palette,
  'monitor-smartphone': MonitorSmartphone,
  film: Film,
  box: Box,
};

interface Props {
  category: Category;
  index: number;
}

export default function CategoryCard({ category, index }: Props) {
  const Icon = iconMap[category.icon] || Building2;

  return (
    <motion.div
      initial={{ opacity: 0, y: 40 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ delay: index * 0.1, duration: 0.5 }}
    >
      <Link
        to={`/category/${category.slug}`}
        className="group relative block overflow-hidden rounded-2xl border border-white/5 bg-gradient-to-br from-[#111827] to-[#0a0e1a] transition-all duration-500 hover:border-[color:var(--card-color)]/40 hover:shadow-[0_0_40px_var(--card-glow)]"
        style={{ '--card-color': category.color, '--card-glow': category.glowColor } as React.CSSProperties}
      >
        {/* Background image */}
        {category.image && (
          <div className="absolute inset-0">
            <img
              src={category.image}
              alt=""
              className="h-full w-full object-cover opacity-20 group-hover:opacity-30 group-hover:scale-110 transition-all duration-700"
            />
            <div className="absolute inset-0 bg-gradient-to-t from-[#0a0e1a] via-[#0a0e1a]/80 to-[#0a0e1a]/60" />
          </div>
        )}

        {/* Background glow */}
        <div
          className="absolute -top-20 -right-20 h-40 w-40 rounded-full opacity-0 group-hover:opacity-100 transition-opacity duration-700 blur-3xl"
          style={{ background: category.glowColor }}
        />

        {/* Scan line effect */}
        <div className="absolute inset-0 opacity-0 group-hover:opacity-100 transition-opacity duration-500 overflow-hidden pointer-events-none">
          <div
            className="absolute inset-0"
            style={{
              backgroundImage: `repeating-linear-gradient(0deg, transparent, transparent 2px, ${category.color}08 2px, ${category.color}08 4px)`,
            }}
          />
        </div>

        {/* Corner brackets */}
        <div className="absolute top-2 left-2 w-4 h-4 border-t-2 border-l-2 opacity-20 group-hover:opacity-60 transition-opacity z-10" style={{ borderColor: category.color }} />
        <div className="absolute top-2 right-2 w-4 h-4 border-t-2 border-r-2 opacity-20 group-hover:opacity-60 transition-opacity z-10" style={{ borderColor: category.color }} />
        <div className="absolute bottom-2 left-2 w-4 h-4 border-b-2 border-l-2 opacity-20 group-hover:opacity-60 transition-opacity z-10" style={{ borderColor: category.color }} />
        <div className="absolute bottom-2 right-2 w-4 h-4 border-b-2 border-r-2 opacity-20 group-hover:opacity-60 transition-opacity z-10" style={{ borderColor: category.color }} />

        <div className="relative z-10 p-6">
          {/* Icon */}
          <div
            className="mb-4 inline-flex items-center justify-center rounded-xl p-3 transition-all duration-300 group-hover:scale-110"
            style={{
              background: `${category.color}15`,
              boxShadow: `0 0 20px ${category.glowColor}`,
            }}
          >
            <Icon className="h-7 w-7" style={{ color: category.color }} />
          </div>

          {/* Title */}
          <h3
            className="font-['Orbitron'] text-lg font-bold tracking-wider mb-2 transition-colors duration-300"
            style={{ color: category.color }}
          >
            {category.title.toUpperCase()}
          </h3>

          {/* Description */}
          <p className="text-sm text-gray-400 leading-relaxed font-['Rajdhani']">
            {category.description}
          </p>

          {/* Enter button */}
          <div className="mt-4 flex items-center gap-2 text-xs font-['Orbitron'] tracking-widest opacity-0 group-hover:opacity-100 transition-all duration-300 translate-x-0 group-hover:translate-x-1" style={{ color: category.color }}>
            <span>INITIALIZE</span>
            <span className="text-lg">→</span>
          </div>
        </div>
      </Link>
    </motion.div>
  );
}
