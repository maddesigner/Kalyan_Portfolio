import { useState } from 'react';
import { Link, useLocation } from 'react-router-dom';
import { Menu, X } from 'lucide-react';
import { motion, AnimatePresence } from 'framer-motion';
import logoImage from '../assets/logo.png';
import { useAuth } from '../lib/auth';

export default function Navbar() {
  const [open, setOpen] = useState(false);
  const location = useLocation();
  const { isAuthenticated } = useAuth();

  const links = [
    { to: '/', label: 'Home' },
    { to: '/contact', label: 'Contact' },
    ...(isAuthenticated ? [{ to: '/dashboard', label: 'Dashboard' }] : []),
  ];

  if (location.pathname === '/signin') return null;

  return (
    <nav className="fixed top-0 left-0 right-0 z-50 border-b border-[#00e676]/20 bg-[#0a0e1a]/90 backdrop-blur-xl">
      <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
        <div className="flex h-16 items-center justify-between">
          <Link to="/" className="flex items-center gap-3 group">
            <img
              src={logoImage}
              alt="Kalyan Sai Logo"
              className="h-10 w-auto object-contain transition-transform group-hover:scale-105 drop-shadow-[0_0_8px_rgba(0,230,118,0.3)]"
            />
          </Link>

          <div className="hidden md:flex items-center gap-6">
            {links.map((link) => (
              <Link
                key={link.to}
                to={link.to}
                className={`font-['Orbitron'] text-sm tracking-wider transition-colors ${
                  location.pathname === link.to
                    ? 'text-[#00e676]'
                    : 'text-gray-400 hover:text-[#00e676]'
                }`}
              >
                {link.label.toUpperCase()}
              </Link>
            ))}
          </div>

          <button
            onClick={() => setOpen(!open)}
            className="md:hidden text-[#00e676] p-2"
          >
            {open ? <X className="w-6 h-6" /> : <Menu className="w-6 h-6" />}
          </button>
        </div>
      </div>

      <AnimatePresence>
        {open && (
          <motion.div
            initial={{ height: 0, opacity: 0 }}
            animate={{ height: 'auto', opacity: 1 }}
            exit={{ height: 0, opacity: 0 }}
            className="md:hidden overflow-hidden border-t border-[#00e676]/10 bg-[#0a0e1a]/95 backdrop-blur-xl"
          >
            <div className="px-4 py-4 space-y-3">
              {links.map((link) => (
                <Link
                  key={link.to}
                  to={link.to}
                  onClick={() => setOpen(false)}
                  className={`block font-['Orbitron'] text-sm tracking-wider ${
                    location.pathname === link.to
                      ? 'text-[#00e676]'
                      : 'text-gray-400'
                  }`}
                >
                  {link.label.toUpperCase()}
                </Link>
              ))}
            </div>
          </motion.div>
        )}
      </AnimatePresence>
    </nav>
  );
}
