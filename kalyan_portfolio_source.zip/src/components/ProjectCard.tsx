import { motion } from 'framer-motion';
import { Box } from 'lucide-react';
import { Project } from '../types';
import { categories } from '../lib/data';

function isSketchfabUrl(url: string): boolean {
  return url.includes('sketchfab.com/3d-models') || url.includes('sketchfab.com/models');
}

interface Props {
  project: Project;
  index: number;
  onClick: () => void;
}

export default function ProjectCard({ project, index, onClick }: Props) {
  const category = categories.find((c) => c.slug === project.category);
  const color = category?.color || '#00e676';
  const glow = category?.glowColor || 'rgba(0,230,118,0.4)';
  const hasSketchfab = project.sketchfabId || (project.link && isSketchfabUrl(project.link));

  return (
    <motion.div
      initial={{ opacity: 0, y: 30 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ delay: index * 0.08, duration: 0.4 }}
      className="group cursor-pointer"
      onClick={onClick}
    >
      <div
        className="relative overflow-hidden rounded-xl border border-white/5 bg-gradient-to-br from-[#111827] to-[#0a0e1a] transition-all duration-500 hover:border-[var(--c)]/30 hover:shadow-[0_0_30px_var(--g)]"
        style={{ '--c': color, '--g': glow } as React.CSSProperties}
      >
        {/* Image area */}
        <div
          className="relative h-48 overflow-hidden"
          style={{ background: `linear-gradient(135deg, ${color}10, ${color}05)` }}
        >
          {project.imageUrl ? (
            <img
              src={project.imageUrl}
              alt={project.title}
              className="h-full w-full object-cover transition-transform duration-500 group-hover:scale-110"
            />
          ) : (
            <div className="flex h-full items-center justify-center">
              <div
                className="font-['Orbitron'] text-4xl font-bold opacity-10"
                style={{ color }}
              >
                {project.title.charAt(0)}
              </div>
            </div>
          )}

          {/* Scan line overlay */}
          <div
            className="absolute inset-0 pointer-events-none opacity-30"
            style={{
              backgroundImage: `repeating-linear-gradient(0deg, transparent, transparent 3px, ${color}06 3px, ${color}06 4px)`,
            }}
          />

          {/* 3D Model badge */}
          {hasSketchfab && (
            <div className="absolute top-3 left-3 flex items-center gap-1.5 px-2.5 py-1 rounded-lg bg-black/60 backdrop-blur-sm border border-[#00bcd4]/30">
              <Box className="h-3 w-3 text-[#00bcd4]" />
              <span className="font-['Orbitron'] text-[8px] tracking-wider text-[#00bcd4]">3D</span>
            </div>
          )}

          {/* Hover overlay */}
          <div className="absolute inset-0 bg-black/50 opacity-0 group-hover:opacity-100 transition-opacity duration-300 flex items-center justify-center">
            <span
              className="font-['Orbitron'] text-xs tracking-widest px-4 py-2 rounded border"
              style={{ color, borderColor: `${color}50` }}
            >
              {hasSketchfab ? 'VIEW 3D MODEL' : 'VIEW DETAILS'}
            </span>
          </div>
        </div>

        {/* Content */}
        <div className="p-4">
          <div className="flex items-start justify-between gap-2 mb-2">
            <h3
              className="font-['Orbitron'] text-sm font-bold tracking-wide leading-tight"
              style={{ color }}
            >
              {project.title.toUpperCase()}
            </h3>
            {hasSketchfab && (
              <Box className="h-3.5 w-3.5 flex-shrink-0 text-[#00bcd4]/60" />
            )}
          </div>
          <p className="text-xs text-gray-500 font-['Rajdhani'] leading-relaxed line-clamp-2">
            {project.description}
          </p>

          {/* Tags */}
          <div className="mt-3 flex flex-wrap gap-1.5">
            {project.tags.slice(0, 3).map((tag) => (
              <span
                key={tag}
                className="font-['Orbitron'] text-[9px] tracking-wider px-2 py-0.5 rounded-full border"
                style={{
                  color: `${color}cc`,
                  borderColor: `${color}30`,
                  background: `${color}08`,
                }}
              >
                {tag.toUpperCase()}
              </span>
            ))}
          </div>

          {/* Date */}
          <div className="mt-3 text-[10px] font-['Orbitron'] tracking-wider text-gray-600">
            {new Date(project.date).toLocaleDateString('en-US', {
              year: 'numeric',
              month: 'short',
            }).toUpperCase()}
          </div>
        </div>
      </div>
    </motion.div>
  );
}
