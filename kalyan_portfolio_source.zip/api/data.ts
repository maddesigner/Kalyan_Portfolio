import { head, put } from '@vercel/blob';
import type { VercelRequest, VercelResponse } from '@vercel/node';

const BLOB_KEY = 'portfolio-data.json';

export default async function handler(req: VercelRequest, res: VercelResponse) {
  // CORS
  res.setHeader('Access-Control-Allow-Origin', '*');
  res.setHeader('Access-Control-Allow-Methods', 'GET, POST, OPTIONS');
  res.setHeader('Access-Control-Allow-Headers', 'Content-Type');
  res.setHeader('Cache-Control', 'no-cache, no-store, must-revalidate');

  if (req.method === 'OPTIONS') {
    return res.status(204).end();
  }

  // GET - read data
  if (req.method === 'GET') {
    try {
      const blobInfo = await head(BLOB_KEY);
      if (!blobInfo) {
        return res.status(200).json({ exists: false });
      }
      const response = await fetch(blobInfo.url, { cache: 'no-store' });
      const data = await response.json();
      return res.status(200).json({ exists: true, data });
    } catch (error: any) {
      return res.status(200).json({ exists: false, error: error.message || 'Blob not configured' });
    }
  }

  // POST - write data
  if (req.method === 'POST') {
    try {
      const body = req.body;
      await put(BLOB_KEY, JSON.stringify(body), {
        access: 'public',
        allowOverwrite: true,
      });
      return res.status(200).json({ success: true });
    } catch (error: any) {
      return res.status(500).json({ success: false, error: error.message || 'Save failed' });
    }
  }

  return res.status(405).json({ error: 'Method not allowed' });
}
